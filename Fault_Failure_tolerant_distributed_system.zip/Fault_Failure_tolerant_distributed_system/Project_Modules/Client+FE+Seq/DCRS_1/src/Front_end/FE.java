package Front_end;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;

import DCRS_1Corba.InterfaceCorba;
import DCRS_1Corba.InterfaceCorbaHelper;
import DCRS_1Corba.InterfaceCorbaPOA;
import client.ClientCheck;


public class  FE extends InterfaceCorbaPOA implements Runnable
{
	private ORB orb;
	
	public void setORB(ORB orb_val) {
		   orb = orb_val; 
		 }
	//String[] rmname= {"RM1","RM2","RM3","RM4"};
	//static String[] rmnamerecieved=null;
	//int capacity=5;
	static int responsecounter=0;
	static int rm1counter=0;
	static int rm2counter=0;
	static int rm3counter=0;
	static int rm4counter=0;
	public static List<String> response=new ArrayList<String>(); 
	static String consensusReply="";
	public static int[] responseArray = {0,0,0,0};
	static boolean timeout=false;
	static int index=0;
	
	public static String sendMessage(String desc) {

		DatagramSocket aSocket = null;
        
		try {
            
			aSocket = new DatagramSocket();
            String mess=desc.trim();
            int sequencerPort = 6666;
            
			byte[] message = mess.getBytes();

			InetAddress aHost = InetAddress.getByName("localhost");

			DatagramPacket request = new DatagramPacket(message, message.length, aHost, sequencerPort);

			aSocket.send(request);

			System.out.println("Request message sent from the frontend to sequencer with port number " + sequencerPort + " is: "

					+ new String(request.getData()));
//			logger.info("Request message sent from the client to server with port number " + serverPort + " is: "

//					+ new String(request.getData()));

//			byte[] buffer = new byte[1000];
//
//			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
//
//			aSocket.receive(reply);

			
			//System.out.println("Reply received from the server with port number " + serverPort + " is: "

				//	 );
			

//			String checkresult = new String(reply.getData());
//			return checkresult;
//			
			
		} catch (SocketException e) {

			System.out.println("Socket: " + e.getMessage());

		} catch (IOException e) {

			e.printStackTrace();

			System.out.println("IO: " + e.getMessage());

		} finally {

			if (aSocket != null)

				aSocket.close();

		}
		return null;

	}

	 
	private static void sendToReplicas(String repManagerAddress, int repManagerPort, String finalRequest) {
		DatagramSocket aSocket = null;
		try {
			aSocket = new DatagramSocket();
			
			byte[] message = finalRequest.getBytes();
			InetAddress aHost = InetAddress.getByName(repManagerAddress);
			DatagramPacket request = new DatagramPacket(message, finalRequest.length(), aHost, repManagerPort);
			aSocket.send(request);
			System.out.println("Request message sent from FE to replicas at port number "+ repManagerPort + " is: "
					+ new String(request.getData()));
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
		
	}	
	
	public  FE() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public  synchronized boolean  addCourse(String courseID, String semester, String capacity) {
		// TODO Auto-generated method stub
		//responsecounter=0;
		String request="addCourse,"+courseID.trim()+","+semester.trim()+","+capacity.trim();
				
		String received;
		sendMessage(request);

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean addboolean = Boolean.parseBoolean(consensusReply);
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in add---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in add---"+responseArray[i]);
		}			
		return addboolean;
	}

	@Override
	public synchronized boolean removeCourse(String courseID, String semester) {
		// TODO Auto-generated method stub
		//responsecounter=0;
		String request="removeCourse,"+courseID.trim()+","+semester.trim();
		String received;
		sendMessage(request);

		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean addboolean = Boolean.parseBoolean(consensusReply);
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in removecourse---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in remove---"+responseArray[i]);
		}
		
		return addboolean;
	}

	@Override
	public synchronized String listCourseAvailability(String semester) {
		// TODO Auto-generated method stub
		responsecounter=0;
		String request="listCourseAvailability,"+semester.trim();
		String received;
		sendMessage(request);

		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in listCourseAvailability---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in listCourseAvailability---"+responseArray[i]);
		}		
		
		return consensusReply;
	}

	@Override
	public synchronized boolean enrolCourse(String studentID, String courseID, String semester) {
		// TODO Auto-generated method stub
		//responsecounter=0;
		
		String request="enrolCourse,"+studentID.trim()+","+courseID.trim()+","+semester.trim();
		String received;
		sendMessage(request);

		
		try {
			Thread.sleep(250);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean enrolboolean = Boolean.parseBoolean(consensusReply);
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in enrol---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in enrol---"+responseArray[i]);
		}
		
		return enrolboolean;
		
	}

	@Override
	public synchronized String getClassSchedule(String studentID) {
		// TODO Auto-generated method stub
		//responsecounter=0;
		String request="getClassSchedule,"+studentID.trim();
		String received;
		sendMessage(request);

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in listCourseAvailability---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in listCourseAvailability---"+responseArray[i]);
		}		
		
		return consensusReply;
		
		
	}

	@Override
	public synchronized boolean dropCourse(String studentID, String courseID) {
		// TODO Auto-generated method stub
		//responsecounter=0;
		String request="dropCourse,"+studentID.trim()+","+courseID.trim();
		String received;
		sendMessage(request);

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean dropboolean = Boolean.parseBoolean(consensusReply);
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in drop---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in drop---"+responseArray[i]);
		}
		
		return dropboolean;
	}

	@Override
	public synchronized boolean swapCourse(String studentID, String oldcourseID, String newcourseID) {
		// TODO Auto-generated method stub
		//responsecounter=0;
		String request="swapCourse,"+studentID.trim()+","+oldcourseID.trim()+","+newcourseID.trim();

		String received;
		sendMessage(request);

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		boolean swapboolean = Boolean.parseBoolean(consensusReply);
		timeout=true;
		System.out.println("consensusReply----"+consensusReply.toString());
		response.clear();
		System.out.print("resonse in swap---"+response);
		for(int i=0;i<responseArray.length;i++) {
			responseArray[i]=0;
			System.out.print("resonse in swap---"+responseArray[i]);
		}
		
		return swapboolean;
	}
	
	
	public static void main(String args[]) throws UserException, RemoteException, InterruptedException {
		
		
		 
		try {
		ORB orb = ORB.init(args, null);
		
		
		POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
		rootpoa.the_POAManager().activate();
		
		org.omg.CORBA.Object objRef =  orb.resolve_initial_references("NameService");
	    NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
	    
	    FE impl = new FE();
	    
	    impl.setORB(orb);
	    
	    org.omg.CORBA.Object objRefComp = rootpoa.servant_to_reference(impl);
	    InterfaceCorba objRefComp1 = InterfaceCorbaHelper.narrow(objRefComp);
		NameComponent nameobjectComp[] = ncRef.to_name("name");
		ncRef.rebind(nameobjectComp, objRefComp1);
		Runnable task = () -> {

			 recieve();
			

		};
	
		Thread thread = new Thread(task);
		
		thread.start();

		java.lang.Object sync=new java.lang.Object();
		synchronized(sync) {
			sync.wait();
		}

		}
		catch (Exception re) {
			System.out.println("Exception " + re);
		}
		
		//orb.sendMessage();
        
		
//		ServerComp.startCompserver();
				
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
	
	/*
	
	public static void waitfunc(List<String> response,int[] responseArray) {
		
		
		System.out.println("inside wait function");
		if (response.size()==3 && timeout==true) {
			System.out.println("response size 3,inside wait");
		

		
		}
		sendToReplicas("230.1.1.5",1313,"faulty,RM"+index);
		}
//		if (timeout==true) {
		if (response.size()==4) {
			
			System.out.println("response size 4,inside wait");
			
			for(int j=0;j<response.size();j++) {
				for(int k=j+1;k<response.size()-1;k++) {
					if (!response.get(j).equals(response.get(k))){
						
						System.out.println("sending faulty message to RM's");
						
						sendToReplicas("230.1.1.5",1313,"faulty,RM"+k);
//						response.clear();
					}
		
					}
				}
					
			}
		
	}
//		}	
	
					*/
			
	public static String consensus(String data) {
		//System.out.println("data---"+data);
		
		String receivedData="";
		String Rm=data.split(":")[1].trim();
		String msg = data.split(":")[0].trim();
		System.out.println("Rm---"+Rm);
		
		System.out.println("msg---"+msg);
		//if (timeout==false) {
		if (Rm.equals("RM1")) {
			//rm1counter=1;
			responseArray[0]=1;		
			response.add( msg);			
		}
		if(Rm.equals("RM2")) {	
			//rm2counter=1;
			responseArray[1]=1;
			response.add( msg);
		}
				
		if(Rm.equals("RM3")) {	
			//rm3counter=1;								
			responseArray[2]=1;
			response.add(msg);
		}				
		if(Rm.equals("RM4")) {	
			//rm4counter=1;
			responseArray[3]=1;
			response.add(msg);
		}	
		//}
		System.out.println(responseArray[0]);
		System.out.println(responseArray[1]);
		System.out.println(responseArray[2]);
		System.out.println(responseArray[3]);
		
		System.out.println("response.size()---"+response.size());
		//System.out.println("timeout----"+timeout);
		

		
		if (response.size()==3 && responseArray[2]==0) {
			
			System.out.println("response size 3,inside wait");
			
			for(int i=0;i<=3;i++){
				if(responseArray[i]==0){
				index = i+1;
				System.out.println("faulty index---"+index);
				System.out.println("sending faulty replica message");
				sendToReplicas("230.1.1.5",1313,"faultycrash,RM"+3);
				break;
				
				}
				
			}
				System.out.println("response.size() uper"+response.size());
			for(int j=0;j<response.size();j++) {
				System.out.println("ch1"+response);
				for(int k=j+1;k<response.size()-1;k++) {
					System.out.println("ch2"+response);
					if (response.get(j).equals(response.get(k))){
						System.out.println("ch3"+response);	
						responsecounter+=1;
												
						if (responsecounter==1) {
							System.out.println("hello");
							System.out.println("responsecounter---"+responsecounter);
							receivedData = response.get(j);
							System.out.println("ch4"+response);
							responsecounter=0;
							return receivedData;
							
						}
					}
				}
					
			}
		
		}
		
		
		if (response.size()==4) {
			
			System.out.println("response size 4,inside wait");
			if (response.get(0).equals(response.get(1))){
				if (response.get(1).equals(response.get(2))){
					if (response.get(2).equals(response.get(3))){
//				k=k+1;					
//				sendToReplicas("230.1.1.5",1313,"faulty,RM"+(k+1));
				receivedData = response.get(2);
				
				return receivedData;						
				}
				}
			}
			String result = response.get(0).trim();
			int countFalse=0;
			int countTrue=0;
			for(int a=1;a<response.size();a++) {
				if(!result.equals(response.get(a).trim())) {
					countFalse++;
				}
				if(result.equals(response.get(a).trim())) {
					countTrue++;
					}
				}
			System.out.println("countfalse--"+countFalse);
			System.out.println("countTure--"+countTrue);
			if(countFalse==2 ||countFalse==3) {
				receivedData = response.get(1);
				sendToReplicas("230.1.1.5",1313,"faultybug,RM"+(3));
				return receivedData;
			}
			if(countTrue==2 ||countTrue==3) {
				receivedData = result;
				sendToReplicas("230.1.1.5",1313,"faultybug,RM"+(3));
				return receivedData;
			}
			/*for(int j=0;j<response.size()-1;j++) {
				for(int k=j+1;k<response.size();k++) {
					if (!response.get(j).equals(response.get(k))){
//						k=k+1	
						System.out.println("k-----"+k);
						System.out.println("j-----"+j);
						sendToReplicas("230.1.1.5",1313,"faultybug,RM"+(3));
						System.out.print("j response--"+response.get(j));
						System.out.print("k response--"+response.get(k));
						receivedData = response.get(j);
					
						return receivedData;						
					}
		
					}
				}*/
					
			} 
					
		return receivedData;		
	}
	
	
	
	public synchronized static String recieve() {
	MulticastSocket aSocket = null;
	try {

		aSocket = new MulticastSocket(1314);

		aSocket.joinGroup(InetAddress.getByName("230.1.1.5"));
		String data=null;
		
		System.out.println("Server Started............");

		while (true) {
			byte[] buffer = new byte[10000];
			DatagramPacket request = new DatagramPacket(buffer, buffer.length);
			aSocket.receive(request);
			String msg = new String(buffer, 0, buffer.length);
			System.out.println(msg);
			//data=request.getData().toString();
			
			//System.out.println(msg);
			//System.out.println(data);*/
			
			consensusReply=consensus(msg);						
		   //	
			//return consensusReply;
			
			
			//DatagramPacket reply = new DatagramPacket(request.getData(), request.getLength(), request.getAddress(),
			//		request.getPort());
			//aSocket.send(reply);
		}

	} catch (SocketException e) {
		System.out.println("Socket: " + e.getMessage());
	} catch (IOException e) {
		System.out.println("IO: " + e.getMessage());
	} finally {
		if (aSocket != null)
			aSocket.close();
	}
	return null;
}


}
	
	
	