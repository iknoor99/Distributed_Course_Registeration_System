package client;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import DCRS_1Corba.InterfaceCorba;
import DCRS_1Corba.InterfaceCorbaHelper;

public class DemoTest extends Thread {
	String serverName;
	String studentID="";
//	String courseID=null;
	String oldcourseID=null;
	String newcourseID=null;
	static  InterfaceCorba intercorba;
	static String[] ref=null;
	String getSchedule;


	String semester=null;
	
	public DemoTest(String studentId,String term,String oldCourseId,String newCourseId) {
		// TODO Auto-generated constructor stub
		
		studentID=studentId.toUpperCase();
		oldcourseID=oldCourseId.toUpperCase();
		newcourseID=newCourseId.toUpperCase();
		semester=term.toUpperCase();
		
	}

	public static void main(String[] args) throws InvalidName {
		
		// TODO Auto-generated method stub
		ref=args;
		DemoTest d1 = new DemoTest("COMPS1111","fall","comp6461","comp6451");
		Thread td1 = new Thread (d1);
		DemoTest d2 = new DemoTest("COMPS1112","fall","comp6461","comp6451");
		Thread td2 = new Thread (d2);
//		DemoTest d3 = new DemoTest("COMPS1113","fall","comp6461","comp6451");
//		Thread td3 = new Thread (d3);
//		DemoTest d4 = new DemoTest("COMPS1114","fall","comp6461","comp6451");
//		Thread td4 = new Thread (d4);
//		DemoTest d5 = new DemoTest("COMPS1115","fall","comp6461","comp6451");
//		Thread td5 = new Thread (d5);
		
		
		DemoTest m1 = new DemoTest("SOENS1111","fall","SOEN6543","SOEN6441");
		Thread tm1 = new Thread (m1);
		DemoTest m2 = new DemoTest("SOENS1112","fall","SOEN6543","SOEN6441");
		Thread tm2 = new Thread (m2);
//		DemoTest m3 = new DemoTest("SOENS1113","fall","SOEN6461","SOEN6451");
//		Thread tm3 = new Thread (m3);
//		DemoTest m4 = new DemoTest("SOENS1114","fall","SOEN6461","SOEN6451");
//		Thread tm4 = new Thread (m4);
//		DemoTest m5 = new DemoTest("SOENS1001","fall","SOEN6461","SOEN6451");
//		Thread tm5 = new Thread (m5);
//		
		
		DemoTest l1 = new DemoTest("INSES1111","fall","INSE6789","INSE3421");
		Thread tl1 = new Thread (l1);		
		DemoTest l2 = new DemoTest("INSES1112","fall","INSE6789","INSE3421");
		Thread tl2 = new Thread (l2);
//		DemoTest l3 = new DemoTest("INSES1003","fall","INSE6461","INSE6451");
//		Thread tl3 = new Thread (l3);
//		DemoTest l4 = new DemoTest("INSES1004","fall","INSE6461","INSE6451");
//		Thread tl4 = new Thread (l4);
//		DemoTest l5 = new DemoTest("INSES1005","fall","INSE6461","INSE6451");
//		Thread tl5 = new Thread (l5);
//		
		
		
		
		
		
//		td1.start();
//		td2.start();
//		td3.start();
//		td4.start();
//		td5.start();
//		
		
//		
//		tm1.start();
//		tm2.start();
//		tm3.start();
//		tm4.start();
//		tm5.start();
//		
		
		
		
		tl1.start();
		tl2.start();
//		tl3.start();
//		tl4.start();
//		tl5.start();
//		
	}

	public void run() {
		ORB orb = ORB.init(ref, null);
		//System.out.println("orb" + orb);
		;
		try {
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			//System.out.println("objRef" + objRef);;
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
			intercorba=(InterfaceCorba) InterfaceCorbaHelper.narrow(ncRef.resolve_str("name"));
		} catch (InvalidName | NotFound | CannotProceed | org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println("objRef" + objRef);
		

		boolean enrollSuccess=intercorba.enrolCourse(studentID, oldcourseID, semester);
		if(enrollSuccess) {
//			logger.info("Enrollment Successful for"+inputID+"for course " +courseId);
			System.out.println("Enrollment Successful for"+studentID+"for course " +oldcourseID+"\n");
			
		}
		else {
//			logger.info("Enrollment unSuccessful for"+inputID+"for course " +courseId);
			System.out.println("Enrollment unSuccessful for"+studentID+"for course " +oldcourseID+"\n");	
		}
		getSchedule=intercorba.getClassSchedule(studentID);
		if(getSchedule!=null) {
//			logger.info("fetched schedule  "+getSchedule);
			
			System.out.printf("fetched schedule %s for student id %s\n",getSchedule,studentID);
			
		}
		else {
//			logger.info("No schedule found for this Id");
			System.out.println("No schedule found for this Id "+studentID+" \n");	
		}
		boolean swapSuccess=intercorba.swapCourse(studentID, oldcourseID, newcourseID);
		if(swapSuccess) {
//			logger.info("Swapped Successfully"+courseId);
			System.out.printf("%s Swapped Successfully \n",oldcourseID);
			
		}
		

		else {
//			logger.info("Unable to swap"+oldcourseID);
			System.out.println("Unable to swap"+oldcourseID+"\n");	
		}

		boolean dropSuccess=intercorba.dropCourse(studentID, newcourseID);
		if(dropSuccess) {
//			logger.info("Dropped Successfully"+courseId);
			System.out.printf("%s Dropped Successfully for student id %s \n",newcourseID,studentID);
			
		}
		

		else {
//			logger.info("Unable to Drop"+courseId);
			System.out.println("Unable to Drop"+oldcourseID+"for student id"+studentID+"\n");	
		}

	}
}