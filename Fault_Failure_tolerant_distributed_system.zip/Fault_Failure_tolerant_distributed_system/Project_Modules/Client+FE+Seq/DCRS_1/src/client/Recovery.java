package client;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import DCRS_1Corba.InterfaceCorba;
import DCRS_1Corba.InterfaceCorbaHelper;

public class Recovery extends Thread {
	String serverName;
	String studentID="";
	String courseID=null;
	String oldcourseID=null;
	String newcourseID=null;
	static  InterfaceCorba intercorba;
	static String[] ref=null;
	String getSchedule;


	String semester=null;
	
	public Recovery(String studentId,String term,String oldCourseId,String newCourseId) {
		// TODO Auto-generated constructor stub
		
		studentID=studentId.toUpperCase();
		oldcourseID=oldCourseId.toUpperCase();
		newcourseID=newCourseId.toUpperCase();
		semester=term.toUpperCase();
		
	}

	public static void main(String[] args) throws InvalidName {
		
		// TODO Auto-generated method stub
		ref=args;
		Recovery d1 = new Recovery("COMPS1111","fall","comp6461","comp9000");
		Thread td1 = new Thread (d1);
		Recovery d2 = new Recovery("COMPS1111","fall","comp6431","comp9001");
		Thread td2 = new Thread (d2);
		Recovery d3 = new Recovery("COMPS1111","fall","comp6481","comp9002");
		Thread td3 = new Thread (d3);
			
		td1.start();
		td2.start();
		td3.start();
//		tl3.start();
//		tl4.start();
//		tl5.start();
//		
	}

	public void run() {
		ORB orb = ORB.init(ref, null);
		//System.out.println("orb" + orb);
		;
		try {
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			//System.out.println("objRef" + objRef);;
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
			intercorba=(InterfaceCorba) InterfaceCorbaHelper.narrow(ncRef.resolve_str("name"));
		} catch (InvalidName | NotFound | CannotProceed | org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		System.out.println("objRef" + objRef);
		boolean addSuccess=intercorba.addCourse(newcourseID,semester,"5");
		if(addSuccess) {
//			logger.info("Enrollment Successful for"+inputID+"for course " +courseId);
			System.out.println("Course "+newcourseID+" added for semester "+semester+" with capacity 5\n");
			
		}
		else {
//			logger.info("Enrollment unSuccessful for"+inputID+"for course " +courseId);
			System.out.println("Add course failed for course "+newcourseID+"\n");	
		}

		boolean enrollSuccess=intercorba.enrolCourse(studentID, oldcourseID, semester);
		if(enrollSuccess) {
//			logger.info("Enrollment Successful for"+inputID+"for course " +courseId);
			System.out.println("Enrollment Successful for"+studentID+"for course " +oldcourseID+"\n");
			
		}
		else {
//			logger.info("Enrollment unSuccessful for"+inputID+"for course " +courseId);
			System.out.println("Enrollment unSuccessful for"+studentID+"for course " +oldcourseID+"\n");	
		}

	}
}