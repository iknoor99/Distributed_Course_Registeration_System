package rmi_Client;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import org.omg.CORBA.ORB;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import DCRS.*;

public class FrontEnd_CORBA extends CORBA_InterfaceDCRSPOA{

		private ORB orb;
		
		public void setORB(ORB orb_val) {
			orb = orb_val;
		}
				
		@Override
		public boolean addCourse(String courseId, String semester, int cap) {
			
			return false;
		}

		@Override
		public synchronized boolean removeCourse(String courseId, String semester) {
			
			return false;
		}

		@Override
		public String listCourseAvailability(String semester) {
			
			return "";
		}

		@Override
		public synchronized boolean enrolCourse(String studentId, String courseId, String semester) {
			
				return false;
			
		}

		@Override
		public synchronized boolean dropCourse(String studentID, String courseID) {
			
			return false;
		}
			
		@Override
		public synchronized boolean swapCourse(String studentID, String newCourseID, String oldCourseID) {
			
			return false;
		}
		
		@Override
		public void shutdown() {
			orb.shutdown(false);
		}

		@Override
		public String getClassSchedule(String studentID) {
			// TODO Auto-generated method stub
			return null;
		}		

}
