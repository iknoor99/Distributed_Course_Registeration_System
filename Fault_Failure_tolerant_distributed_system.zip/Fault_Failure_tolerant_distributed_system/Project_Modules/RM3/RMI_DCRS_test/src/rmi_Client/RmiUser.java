package rmi_Client;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import DCRS.CORBA_InterfaceDCRS;
import DCRS.CORBA_InterfaceDCRSHelper;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import rmi_Server.RmiComp;
import rmi_Server.RmiInse;
import rmi_Server.RmiSoen;

public class RmiUser {

	Scanner input = new Scanner(System.in);
	String userId;
	String registryURL=null;
	int RMIPort;
	String courseId = null;
	int courseCapacity = 0;
	String oldCourseId = null;
	String newCourseId = null;
	String term = null;
	int moreChoice = 0;
	Logger logger = Logger.getLogger(RmiUser.class.getName());
	static private FileHandler fileTxt;
    static private SimpleFormatter formatterTxt;
	Boolean flag = false;
	String studentId = null;
	boolean checkFlag = false;
	boolean conditions = false;
	String classSchedule;
	boolean addC = false;
	String liResult="";
	boolean swapFlag=false;
	//ORB orb;
	static CORBA_InterfaceDCRS rmiInterface;
	
	String[] Ids =      {"COMPS1122","COMPS2233","COMPS3344","COMPS4455",
						"SOENS1122","SOENS2233", "SOENS3344","SOENS4455",
						"INSES1122","INSES2233","INSES3344","INSES4455",
						"COMPA1111","COMPA2222","COMPA3333","COMPA4444",
						"SOENA1111","SOENA2222", "SOENA3333","SOENA4444",
						"INSEA1111","INSEA2222","INSEA3333","INSEA4444"};
	
	private boolean checkUser(String userId) {
		for(int i=0;i<Ids.length;i++) {
			if(Ids[i].equals(userId)) {
				//System.out.println("1");
				//flag = true;
				//break;
				return true;
			}
		}
		
		return false;
	}
	public void user(String[] args) throws SecurityException, NotBoundException, IOException, InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName {
		//orb = (ORB) ORB.init(args,null);
		System.out.println("Enter the Id:");
		userId = input.nextLine().trim().toUpperCase();
		System.out.println(userId);
		checkFlag = checkUser(userId);
		
		if(checkFlag) {
			callServer(userId,args);
	}
		else {
			logger.info("Incorrect User Id entered");
			System.out.println("Incorrect User Id entered");
			user(args);
		}
	}
	
	public void callServer(String userId, String[] args) throws NotBoundException, SecurityException, IOException, InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName{
		rmiInterface = null;
	   // logger.setLevel(Level.INFO);
	    fileTxt = new FileHandler("C:\\Users\\aakash\\eclipse-workspace\\RMI_DCRS\\"+userId+".log");
	    formatterTxt = new SimpleFormatter();
        fileTxt.setFormatter(formatterTxt);
        logger.addHandler(fileTxt);
     //   System.out.println("orb" + orb);
		//org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
		//System.out.println("objRef" + objRef);
		//NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
		//System.out.println("ncRef" + ncRef);
		String userDept = userId.substring(0,4).toUpperCase().trim();
		if(userDept.equals("COMP")) {
			/*RMIPort = 3535;
			registryURL =
	      //  		 "rmi://localhost:" + RMIPort + "/rmiComp";*/
		//	rmiInterface = CORBA_InterfaceDCRSHelper.narrow(ncRef
				//	.resolve_str("RmiComp"));
		}
		else if(userDept.equals("SOEN")) {
			/*RMIPort = 3636;
			registryURL = 
	        		 "rmi://localhost:" + RMIPort + "/rmiSoen";*/
			//rmiInterface = CORBA_InterfaceDCRSHelper.narrow(ncRef
					//.resolve_str("RmiSoen"));
		}
		else if(userDept.equals("INSE")) {
			/*RMIPort = 3737;
			registryURL = 
	        		 "rmi://localhost:" + RMIPort + "/rmiInse";*/
		//	rmiInterface = CORBA_InterfaceDCRSHelper.narrow(ncRef
			//		.resolve_str("RmiInse"));
		}
		//System.out.println(registryURL);
		/*rmi_Server.Rmi_InterfaceDCRS rmiInterface =
		           (rmi_Server.Rmi_InterfaceDCRS)Naming.lookup(registryURL);*/
		
		String check = userId.substring(4,5).toUpperCase();
		if(check.equals("S")) {
			callStudent(userId, rmiInterface);
		}
		else if(check.equals("A")) {
			callAdvisor(userId, rmiInterface);
		}
		//callUserMethods(userId,rmiInterface);
	}
	
	public void callAdvisor(String userId, CORBA_InterfaceDCRS rmiInterface) throws RemoteException {
		while(true) {
		System.out.println("Do you wish to perform operation for a specific student: ");
		System.out.println("1. yes");
		System.out.println("2. no");
		String advDept = userId.substring(0,4).trim().toUpperCase();
		String option = null;
		option = input.next();
		switch(option) {
		case "1":		
			while(true) {
			System.out.println("Enter the student Id: ");
			//System.out.println("a");
			studentId = input.next().toUpperCase();
			System.out.println("student Id: "+studentId);
			checkFlag = checkUser(studentId);
			//System.out.println("2");
			System.out.println(checkFlag);
			if(checkFlag) {
				String check = studentId.substring(4,5).toUpperCase();
				if(check.equals("S")) {
				//System.out.println("b");
				callStudent(studentId, rmiInterface);
				}
				else {
					logger.info("Incorrect Student Id "+ studentId+ " entered.");
					System.out.println("Incorrect Student Id entered.");
					continue;
				}
			}
			else {
				logger.info("Incorrect Student Id entered.");
				System.out.println("Incorrect Student Id entered.");
				continue;
			}
			break;
		}
		break;	
		case "2":
			while(true) {
			String choice = null;
			System.out.println("Please select the options below: ");
			System.out.println("1. Add Course");
			System.out.println("2. List Course Availability");
			System.out.println("3. Remove Course");
			choice = input.next();
			switch(choice) {
			case "1":
				System.out.println("Enter the courseId:\n ");
				courseId = input.next().toUpperCase();
				System.out.println("Enter the term:\n ");
				term = input.next();
				String course = courseId.substring(0, 4).toUpperCase();
				System.out.println("Enter the capacity: \n ");
				courseCapacity = input.nextInt();
				if(advDept.equals("COMP")) {
					if(course.equals("COMP")) {
						addC=rmiInterface.addCourse(courseId, term,courseCapacity);
						if(addC) {
							logger.info("Course: "+ courseId+ " Added");
							System.out.println("Course "+ courseId+ " Added");
						}
					}
					else {
						logger.info("Course "+courseId +" cannot be added");
						System.out.println("Course cannot be added");
					}
				}
				else if(advDept.equals("SOEN")) {
					if(course.equals("SOEN")) {
						addC= rmiInterface.addCourse(courseId, term,courseCapacity);
						if(addC) {
							logger.info("Course: "+ courseId+ " Added");
							System.out.println("Course: "+ courseId+ " Added");
						}
					}
					else {
						logger.info("Course "+courseId +" cannot be added");
						System.out.println("Course cannot be added");
					}
				}
				
				else if(advDept.equals("INSE")) {
					if(course.equals("INSE")) {
						addC = rmiInterface.addCourse(courseId, term,courseCapacity);
						if(addC) {
							logger.info("Course: "+ courseId+ " Added");
							System.out.println("Course: "+ courseId+ " Added");
						}
					}
					else {
						logger.info("Course "+courseId +" cannot be added");
						System.out.println("Course cannot be added");
					}
				}
				
				break;
			case "2":
				System.out.println("Enter the term:\n ");
				term = input.next();
				if(advDept.equals("COMP")) {
					liResult = rmiInterface.listCourseAvailability(term+"C");
					logger.info("\n List of available courses----"+liResult);
					System.out.println("\n List of available courses----"+liResult);
					if(liResult==null) {
						logger.info("No course available in: "+ advDept+" department");
						System.out.println("No course available in: "+ advDept+" department");
					}
				}
				else if(advDept.equals("INSE")) {
					liResult = rmiInterface.listCourseAvailability(term+"I");
					logger.info("\n List of available courses----"+liResult);
					System.out.println("\n List of available courses----"+liResult);
					if(liResult==null) {
						logger.info("No course available in: "+ advDept+" department");
						System.out.println("No course available in: "+ advDept+" department");
					}
				}
				else if(advDept.equals("SOEN")) {
					liResult = rmiInterface.listCourseAvailability(term+"S");
					logger.info("\n List of available courses----"+liResult);
					System.out.println("\n List of available courses----"+liResult);
					if(liResult==null) {
						logger.info("No course available in: "+ advDept+" department");
						System.out.println("No course available in: "+ advDept+" department");
					}
				}
				break;
			case "3":
				System.out.println("Enter the courseId:\n ");
				courseId = input.next().trim().toUpperCase();
				System.out.println("Enter the term:\n ");
				term = input.next();
				String courseR = courseId.substring(0, 4).toUpperCase();
				if(advDept.equals("COMP")) {
					if(courseR.equals("COMP")) {
						addC=rmiInterface.removeCourse(courseId, term);
						if(addC) {
							logger.info("Course: "+ courseId+ " Removed");
							System.out.println("Course: "+ courseId+ " Removed");
						}
						else {
							logger.info("Course: "+ courseId+ " not available");
							System.out.println("Course: "+ courseId+ " not available");
						}
					}
					else {
						logger.info("Course: "+ courseId+ " not available");
						System.out.println("Course: "+ courseId+ " not available");
					}
				}
				else if(advDept.equals("SOEN")) {
					if(courseR.equals("SOEN")) {
						addC= rmiInterface.removeCourse(courseId, term);
						if(addC) {
							logger.info("Course: "+ courseId+ " Removed");
							System.out.println("Course: "+ courseId+ " Removed");
						}
					}
					else {
						logger.info("Course: "+ courseId+ " not available");
						System.out.println("Course: "+ courseId+ " not available");
					}
				}
				
				else if(advDept.equals("INSE")) {
					if(courseR.equals("INSE")) {
						addC = rmiInterface.removeCourse(courseId, term);
						if(addC) {
							logger.info("Course: "+ courseId+ " Removed");
							System.out.println("Course: "+ courseId+ " Removed");
						}
					}
					else {
						logger.info("Course: "+ courseId+ " not available");
						System.out.println("Course: "+ courseId+ " not available");
					}
				}
				
				break;
			default:
				logger.info("Invalid Entry");
				System.out.println("Invalid Entry");
				continue;
		}
		break;
	}
		break;
	default:
		logger.info("Incorrect option entered.\\n");
		System.out.println("Incorrect option entered.\n");
		callAdvisor(userId, rmiInterface);
			
	}
		System.out.println("Do you wish to perform more operations:");
		System.out.println("1. Yes");
		System.out.println("2. No");
		moreChoice = input.nextInt();
		if(moreChoice==1) {
			continue;
		}
		else if(moreChoice==2) {
			break;
		}
	}
		
}
	public void callStudent(String userId, CORBA_InterfaceDCRS rmiInterface) throws RemoteException {
		while(true) {
		System.out.println("Please select the options below: ");
		System.out.println("1. Enroll Course");
		System.out.println("2. Get Class Schedule");
		System.out.println("3. Drop Course");
		System.out.println("4. Swap Course");
		String choice = input.next();
		switch(choice) {
		case "1":
			System.out.println("Enter the courseId:\n ");
			courseId = input.next().toUpperCase();
			System.out.println("Enter the term:\n ");
			term = input.next().toLowerCase();
			conditions = rmiInterface.enrolCourse(userId, courseId, term);
			if(conditions) {
				logger.info("Student is enrolled in Course : "+courseId);
				System.out.println("Student is enrolled in Course : "+courseId);
			}
			else {
				logger.info("Student cannot be enrolled in Course : "+courseId);
				System.out.println("Student cannot be enrolled in Course : "+courseId);
			}
			break;
		case "2":
			classSchedule = rmiInterface.getClassSchedule(userId);
			System.out.println("Student: " + userId + " classSchedule is: "+ classSchedule);
			if(classSchedule==null) {
				logger.info("Student is not enrolled in any class");
				System.out.println("Student is not enrolled in any class");
			}
			break;
		case "3":
			System.out.println("Enter the courseId: ");
			courseId = input.next().toUpperCase();
			conditions = rmiInterface.dropCourse(userId,courseId);
			if(conditions) {
				logger.info("Student is de-enrolled from Course : "+courseId);
				System.out.println("Student is de-enrolled from Course : "+courseId);
			}
			else {
				logger.info("course doesn't exist: "+courseId);
				System.out.println("course doesn't exist: "+courseId);
			}
			break;
		case "4":
			System.out.println("Enter the course you wish to drop: ");
			oldCourseId = input.next().trim().toUpperCase();
			System.out.println("Enter the course you wish to enroll: ");
			newCourseId = input.next().trim().toUpperCase();
			swapFlag = rmiInterface.swapCourse(userId,newCourseId,oldCourseId);
			if(swapFlag) {
				logger.info("swap successful");
				System.out.println("swap successful");
			}
			else {
				logger.info("swap unsuccessful");
				System.out.println("swap unsuccessful");
			}
			break;
		default:
			logger.info("Invalid Entry");
			System.out.println("Invalid Entry");
			callStudent(userId,rmiInterface);
			break;
		}
		
		System.out.println("Do you wish to perform more operations:");
		System.out.println("1. Yes");
		System.out.println("2. No");
		moreChoice = input.nextInt();
		if(moreChoice==1) {
			continue;
		}
		else if(moreChoice==2) {
			break;
		}
	}
}
	public static void main(String args[]) throws NotBoundException, SecurityException, IOException, InvalidName, NotFound, CannotProceed, org.omg.CosNaming.NamingContextPackage.InvalidName {
		   RmiUser rmi = new RmiUser();
		   rmi.user(args);				
	   }
}
