package rmi_Client;

import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;

import DCRS.CORBA_InterfaceDCRS;
import DCRS.CORBA_InterfaceDCRSHelper;
import DCRS._CORBA_InterfaceDCRSStub;
import rmi_Server.RmiMethods;
import org.omg.CORBA.*;


public class TestData extends Thread {
 private String studentId="";
 private String courseId="";
 private String semester="";
 private String newCourse="";
 private boolean enroll = false;
 private boolean drop = false;
 private boolean swap = false;
 private String classSchedule=null;
 private String sername="";
 static String serverArg[] = null;
 
 
 public TestData(String serverName, String studId, String  courId, String sem, String newCour) {
  studentId = studId.toUpperCase();
  courseId = courId.toUpperCase();
  semester=sem;
  newCourse=newCour.toUpperCase();
  sername=serverName;
 }
 
 public static void main(String[] args) {
  serverArg =args;
  TestData t1 = new TestData("RmiComp","comps1122","comp6431","fall","comp5555");
  Thread tt1 = new Thread(t1);
  TestData t2 = new TestData("RmiSoen","soens2233","soen6431","fall","comp5555");
  Thread tt2 = new Thread(t2);
  TestData t3 = new TestData("RmiInse","inses3344","comp6431","fall","comp5555");
  Thread tt3 = new Thread(t3);
  
  TestData t4 = new TestData("RmiSoen","soens4455","soen8888","summer","soen6666");
  Thread tt4 = new Thread(t4);
  TestData t5 = new TestData("RmiComp","comps5566","soen8888","summer","soen6666");
  Thread tt5 = new Thread(t5);
  TestData t6 = new TestData("RmiInse","inses6677","soen8888","summer","soen6666");
  Thread tt6 = new Thread(t6);
  
  /*TestData t7 = new TestData("RmiComp","comps7788","comp6431","fall","");
  Thread tt7 = new Thread(t7);
  TestData t8 = new TestData("RmiInse","inses8899","comp6431","fall","");
  Thread tt8 = new Thread(t8);
  TestData t9 = new TestData("RmiInse","inses1234","comp6431","fall","");
  Thread tt9 = new Thread(t9);
  TestData t10 = new TestData("RmiInse","comps5678","comp6431","fall","");
  Thread tt10 = new Thread(t10);*/
  
  
  tt1.start();
  tt2.start();
  tt3.start();
  //tt4.start();
 // tt5.start();
 // tt6.start();
 /* tt7.start();
  tt8.start();
  tt9.start();
  tt10.start();*/
  }
 
 public void run() {
  CORBA_InterfaceDCRS corbaserver = null;
  try {
   ORB objectorb = (ORB) ORB.init(serverArg, null);
   org.omg.CORBA.Object objectreferencevariable = objectorb.resolve_initial_references("NameService");
   NamingContextExt newreferencethere = NamingContextExtHelper.narrow(objectreferencevariable);
   corbaserver = CORBA_InterfaceDCRSHelper.narrow(newreferencethere.resolve_str(sername));

  }
  catch (CannotProceed e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  } catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  } 
 catch (NotFound e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (InvalidName e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
 
  enroll = corbaserver.enrolCourse(studentId, courseId, semester);
  if(enroll) {
   System.out.println("Student is enrolled in Course : "+courseId);
  }
  else {
   System.out.println("Student cannot be enrolled in Course : "+courseId);
  }
  
  classSchedule = corbaserver.getClassSchedule(studentId);
  System.out.println("Student: " + studentId + " classSchedule is: "+ classSchedule);
  if(classSchedule==null) {
   System.out.println("Student is not enrolled in any class");
  }
  
  swap = corbaserver.swapCourse(studentId,newCourse,courseId);
  if(swap) {
   System.out.println("swap successful for:"+ studentId);
  }
  else {
   System.out.println("swap unsuccessful for: "+ studentId);
  }
  
  drop = corbaserver.dropCourse(studentId,courseId);
  if(drop) {
   
   System.out.println("Student is de-enrolled from Course : "+courseId);
  }
  else {
   System.out.println("course doesn't exist: "+courseId);
  }
   
 	}
}