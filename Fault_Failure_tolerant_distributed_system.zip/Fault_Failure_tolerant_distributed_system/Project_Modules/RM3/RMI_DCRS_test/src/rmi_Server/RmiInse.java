package rmi_Server;

import java.awt.List;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Arrays;
import java.util.HashMap;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import DCRS.CORBA_InterfaceDCRS;
import DCRS.CORBA_InterfaceDCRSHelper;
import rmi_Client.RmiUser;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
public class RmiInse {
	static HashMap<String, Integer> hash;
	static HashMap<String, Integer>hashDataseminner =new HashMap<String, Integer>();
	static HashMap<String, HashMap<String, Integer>> hashDataInse=new HashMap<String, HashMap<String, Integer>>();
	static HashMap<String, Integer> hashI = new  HashMap<String, Integer>();
	static String liTerm = "";
	static String rep="";
	static String getData = "";
	static String studId="";
	static String corId="";
	static String enrolRes="";
	static Logger logger = Logger.getLogger(RmiUser.class.getName());
	static private FileHandler fileTxt;
    static private SimpleFormatter formatterTxt;
	static HashMap<String, Integer> getValue;
	static HashMap<String, Integer> getValueDrop;
	public static void startRmiInse() throws RemoteException, MalformedURLException {
		ORB orb = ORB.init();
		try {
			Runnable task = () -> {
				receive();
			};
			Thread thread = new Thread(task);
			thread.start();
	        inputValues("FALL");
	        inputValues("SUMMER");
	        inputValues("WINTER");
			fileTxt = new FileHandler("G:\\workspace\\RMI_DCRS_test\\RmiInse.log");
		    formatterTxt = new SimpleFormatter();
	        fileTxt.setFormatter(formatterTxt);
	        logger.addHandler(fileTxt);
	        System.out.println("RmiSoen Server ready and waiting ...");
	        logger.info("RmiInse Server registered");
	        System.out.println("RmiInse Server registered"); 
	        System.out.println("RmiInse Server ready.");
	      //  rmiImp.createhashmap("rmiInse");
		}
		catch(Exception e) {
			System.out.println("Exception in RmiInse: " + e);
		}
	}
public static void inputValues(String term) throws RemoteException {
		
		/*if(term == "fall") {
			hash = new HashMap<String, Integer>();
			hash.put("INSE6431", 10);
			hash.put("INSE6461", 10);
			hash.put("INSE6451", 10);
			hash.put("INSE6481", 10);
			
			if(!hashDataInse.containsKey(term)) {
				hashDataInse.put(term, hash);
				
			}
		}
		
		if(term == "summer") {
			hash = new HashMap<String, Integer>();
			hash.put("INSE6592", 10);
			hash.put("INSE6593", 10);
			hash.put("INSE6594", 10);
			hash.put("INSE6595", 10);
			if(!hashDataInse.containsKey(term)) {
				hashDataInse.put(term, hash);
				
			}
		}
		
		if(term == "winter") {
			hash = new HashMap<String, Integer>();
			hash.put("INSE6641", 10);
			hash.put("INSE6651", 10);
			hash.put("INSE6681", 10);
			hash.put("INSE6621", 10);
			if(!hashDataInse.containsKey(term)) {
				hashDataInse.put(term, hash);
				
			}
		}*/
	
	if(term == "FALL") {
		logger.info("***Adding Fall Courses in Inse Hashmap***");
		hash = new HashMap<String, Integer>();
		hash.put("INSE6789", 10);
		hash.put("INSE3421", 10);
		hash.put("INSE4387", 10);
		hash.put("INSE5436", 10);
		if(!hashDataInse.containsKey(term)) {
			hashDataInse.put(term, hash);
		}
	}

	if(term == "SUMMER") {
		logger.info("***Adding Summer Courses in Inse Hashmap***");
		hash = new HashMap<String, Integer>();
		hash.put("INSE4327", 10);
		hash.put("INSE6543", 10);
		hash.put("INSE6432", 10);
		hash.put("INSE5412", 10);
		if(!hashDataInse.containsKey(term)) {
			hashDataInse.put(term, hash);
		}

	}
	if(term == "WINTER") {
		logger.info("***Adding Winter Courses in Inse Hashmap***");
		hash = new HashMap<String, Integer>();
		hash.put("INSE6732", 10);
		hash.put("INSE6715", 10);
		hash.put("INSE6732", 10);
		hash.put("INSE6165", 10);
		if(!hashDataInse.containsKey(term)) {
			hashDataInse.put(term, hash);
		}
	}
}


public static String sendMessage(int serverPort,String common) {

	DatagramSocket aSocket = null;

	try {

		aSocket = new DatagramSocket();
        String text=common;
        
		byte[] message = text.getBytes();

		InetAddress aHost = InetAddress.getByName("localhost");

		DatagramPacket request = new DatagramPacket(message, message.length, aHost, serverPort);

		aSocket.send(request);
		logger.info("Request message sent from the client to server with port number " + serverPort + " is: "

					+ new String(request.getData()));
		System.out.println("Request message sent from the client to server with port number " + serverPort + " is: "

				+ new String(request.getData()));

		byte[] buffer = new byte[1000];

		DatagramPacket reply = new DatagramPacket(buffer, buffer.length);

		aSocket.receive(reply);
		getData = new String(reply.getData());
		logger.info("Reply received from the server with port number " + serverPort + " is: "

					+ new String(reply.getData()));
		System.out.println("Reply received from the server with port number " + serverPort + " is: "

				+ new String(reply.getData()));
		

	} catch (SocketException e) {
		logger.info("Socket: " + e.getMessage());
		System.out.println("Socket: " + e.getMessage());

	} catch (IOException e) {

		e.printStackTrace();
		logger.info("IO: " + e.getMessage());
		System.out.println("IO: " + e.getMessage());

	} finally {

		if (aSocket != null)

			aSocket.close();

	}
	return getData;

}


private static void receive() {

	DatagramSocket aSocket = null;

	try {

		aSocket = new DatagramSocket(6666);
		logger.info("RmiInse server started............");
		System.out.println("RmiInse 6666 Started............");

		while (true) {
			byte[] buffer = new byte[1000];
			DatagramPacket request = new DatagramPacket(buffer, buffer.length);

			aSocket.receive(request);
			String stringdata=new String (request.getData());		    
		    
			//String stringdatasem = stringdata.split(":")[1].trim();
			String index[] = stringdata.split(",");
			System.out.println("index length--" + index.length);
			if(index.length<3) {
				liTerm = index[0];
				System.out.println("liTerm--" + liTerm);
			}
			else if(index.length<5) {
				//studId = index[0].trim();
				corId = index[0].trim();
				liTerm = index[1].trim();
				System.out.println("studId--" + studId);
				System.out.println("corId--" + corId);
				System.out.println("liTerm--" + liTerm);
			}
			String methodName = index[index.length - 1].trim();
			System.out.println("methodName inse--" + methodName);
			if(methodName.equals("LI")) {
				System.out.println("methodName in Li--");
				rep = getLi(liTerm);
			}
			else if(methodName.trim().equals("enroll")) {
				System.out.println("in get inse");
				rep = getEnrollDetails(corId,liTerm);
			}
			else if(methodName.equals("drop")) {
				rep = getDrop(liTerm);
			}
			buffer = rep.getBytes();

			DatagramPacket reply = new DatagramPacket(buffer, buffer.length, request.getAddress(),

					request.getPort());			
		
			aSocket.send(reply);

		}

	} catch (SocketException e) {
		logger.info("Socket: " + e.getMessage());
		System.out.println("Socket: " + e.getMessage());

	} catch (IOException e) {
		logger.info("IO: " + e.getMessage());
		System.out.println("IO: " + e.getMessage());

	} finally {

		if (aSocket != null)

			aSocket.close();

	}

}
		private static String getDrop(String liTerm) {
			synchronized(hashDataInse) {
			for(String s:hashDataInse.keySet()) {
				System.out.println("soen---"+s);
				getValueDrop  =hashDataInse.get(s);
				for(String sa:getValueDrop.keySet()) {
					if(sa.equals(liTerm)) {
						int cap = getValueDrop.get(sa);
						cap++;
						getValueDrop.put(sa, cap);
						hashDataInse.put(s, getValueDrop);
						logger.info(liTerm+" Successfully dropped");
						return "true";
					}
				}
			}
		}
		return null;
		}
	private static String getEnrollDetails(String corId, String liTerm) {
		synchronized(hashDataInse) {
		if(hashDataInse.containsKey(liTerm)) {
			System.out.println("we are here 3");
			System.out.println("hasmap data: "+hashDataInse.get(liTerm));
			getValue = hashDataInse.get(liTerm);
			if(getValue.containsKey(corId)) {
				System.out.println("we are here 4");
				System.out.println("capacity: "+getValue.get(corId));
				int capacity  = getValue.get(corId);
				if(capacity>0){
					System.out.println("we are here 5");
					capacity--;
					getValue.put(corId, capacity);
					hashDataInse.put(liTerm, getValue);
					logger.info("Updated INSE hashmap: "+hashDataInse);
					return "true";
				}
				else {
				logger.info("Course "+corId+ " is full for "+ liTerm );
				}
			}
		}
	}
	return "false";
}
	
	public static String getDetails(String courseId, String semester) {
		String checkCourse = courseId.substring(0,4);
		String common = courseId.toUpperCase().trim()+","+semester+","+"enroll";
		System.out.println("common---"+common);
		if(checkCourse.equals("INSE")) {
			synchronized(hashDataInse) {
			if(hashDataInse.containsKey(semester)) {
				System.out.println("we are here 3");
				System.out.println("hasmap data: "+hashDataInse.get(semester));
				getValue = hashDataInse.get(semester);
				if(getValue.containsKey(courseId.toUpperCase().trim())) {
					System.out.println("we are here 4");
					System.out.println("capacity: "+getValue.get(courseId));
					int capacity  = getValue.get(courseId);
					if(capacity>0){
						System.out.println("we are here 5");
						capacity--;
						getValue.put(courseId, capacity);
						hashDataInse.put(semester, getValue);
						System.out.println("hashDataInse---"+hashDataInse);
						return "true";
					}
				}
			}
		}
		}
		else if(checkCourse.equals("SOEN")) {
			enrolRes = sendMessage(7777,common);
			System.out.println("enrolRes ----" +enrolRes);
			return enrolRes.trim();
		}
		else if(checkCourse.equals("COMP")) {
			enrolRes = sendMessage(5555,common);
			System.out.println("enrolRes ----" +enrolRes);
			return enrolRes.trim();
		}
		return enrolRes;
	}
	private static String getLi(String liTerm) {
		System.out.println("ii1-----");
		HashMap<String, Integer> data = hashDataInse.get(liTerm);
		String  i = data.toString().trim();
		logger.info("List of courses available in "+liTerm + " are: "+ i);
		System.out.println("ii-----"+i);
	return i;
	}

	public static String listCourseAvailability(String semester) {
		String result="";
		HashMap<String, Integer> data = hashDataInse.get(semester);
		result = "INSE" + data.toString();
		result= result + " "+"COMP" + sendMessage(5555,semester+","+"LI").trim() + " "+"SOEN"+ sendMessage(7777,semester+","+"LI").trim();
		logger.info("list of available courses: "+ result);
		System.out.println("result inse ----" +result);
	    return result;
	}
	public static String getDropDetails(String courseId) {
		String dropC = "";
		String checkCourse = courseId.trim().substring(0,4).toUpperCase();
		String common = courseId.trim().toUpperCase()+","+"drop";
		System.out.println("common---"+common);
		if(checkCourse.equals("INSE")) {
			synchronized(hashDataInse) {
			for(String s:hashDataInse.keySet()) {
				System.out.println("s---"+s);
				getValueDrop  =hashDataInse.get(s);
				for(String sa:getValueDrop.keySet()) {
					if(sa.equals(courseId)) {
						int cap = getValueDrop.get(sa);
						cap++;
						getValueDrop.put(sa, cap);
						hashDataInse.put(s, getValueDrop);
						logger.info("Course "+courseId+" is dropped");
						return "true";
					}
				}
			}
		}	
	}
		else if(checkCourse.equals("COMP")) {
			dropC = sendMessage(5555,common);
			System.out.println("dropC ----" +enrolRes);
			return dropC.trim();
		}
		else if(checkCourse.equals("SOEN")) {
			dropC = sendMessage(7777,common);
			System.out.println("dropC ----" +enrolRes);
			return dropC.trim();
		}
		return "false";
	}
}
