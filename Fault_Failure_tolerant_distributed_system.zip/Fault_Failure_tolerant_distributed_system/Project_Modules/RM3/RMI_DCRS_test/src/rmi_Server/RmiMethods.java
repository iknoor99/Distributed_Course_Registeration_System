package rmi_Server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import org.omg.CORBA.ORB;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import DCRS.*;

public class RmiMethods {
	/*private ORB orb;*/
	
	/*public void setORB(ORB orb_val) {
		orb = orb_val;
	}*/
	
	//HashMap<String, HashMap<String, Integer>> RmiComp.hashDataComp=new HashMap<String, HashMap<String, Integer>>();
	HashMap<String, HashMap<String, Integer>> hashDataSoen=new HashMap<String, HashMap<String, Integer>>();
	HashMap<String, HashMap<String, Integer>> hashDataInse=new HashMap<String, HashMap<String, Integer>>();
	static HashMap<String, HashMap<String,HashSet<String>>> enroll = new HashMap<String, HashMap<String,HashSet<String>>>();
	HashMap<String, Integer> getValue;
	//HashMap<String,HashSet<String>> addCourse;
	HashMap<String,HashSet<String>> getStudentId;
	HashSet<String> hashset;	
	boolean removeFlag = false;
	HashMap<String,HashSet<String>> classSchedule;
	HashSet<String> fetchhashset;
	HashMap<String, HashMap<String, Integer>> hashData;
	Boolean checkTask=false;
	int check=0;
	String enrolRes="";
	Boolean checkEnroll = false;
	Boolean swapDFlag = false;
	Boolean swapEFlag = false;
	static String swapSem = "";
	static int recover=0;
	
	public String addCourse(String courseId, String semester, int cap) throws InterruptedException {
	//	System.out.println("recoveryy---"+recover);
	//	System.out.println("Comp Hashmap"+RmiComp.hashDataComp);
		//if(recover>1) {
		String course = courseId.substring(0, 4).toUpperCase();
		
		if(course.equals("COMP")){
			if(!RmiComp.hashDataComp.get(semester).containsKey(courseId)) {
				RmiComp.hashDataComp.get(semester).put(courseId,cap);
				System.out.println("COMP:"+RmiComp.hashDataComp);
				return "true";
			}
			
		}
		else if(course.equals("SOEN")){
			if(!RmiSoen.hashDataSoen.get(semester).containsKey(courseId)) {
				System.out.println("SOEN:"+RmiSoen.hashDataSoen);
				RmiSoen.hashDataSoen.get(semester).put(courseId,cap);
				return "true";
			}
			
		}
		else if(course.equals("INSE")){
			if(!RmiInse.hashDataInse.get(semester).containsKey(courseId)) {
				System.out.println("INSE:"+RmiInse.hashDataInse);
				RmiInse.hashDataInse.get(semester).put(courseId,cap);
				return "true";
			}
		}
		return "false";
		
		
	}

	public synchronized boolean removeCourse(String courseId, String semester) {
		System.out.println("entered in R--");
		String course = courseId.substring(0, 4).trim().toUpperCase();
		if(course.equals("COMP")){
			System.out.println("entered comp");
			if(RmiComp.hashDataComp.get(semester).containsKey(courseId)) {
				RmiComp.hashDataComp.get(semester).remove(courseId);
				System.out.println("RmiComp.hashDataComp Removed----"+RmiComp.hashDataComp);
				removeFlag = true;
			}
			
		}
		else if(course.equals("SOEN")){
			if(RmiSoen.hashDataSoen.get(semester).containsKey(courseId)) {
				RmiSoen.hashDataSoen.get(semester).remove(courseId);
				System.out.println("RmiSoen.hashDataSoen Removed---"+RmiSoen.hashDataSoen);
				removeFlag = true;
			}
			
		}
		else if(course.equals("INSE")){
			if(RmiInse.hashDataInse.get(semester).containsKey(courseId)) {
				RmiInse.hashDataInse.get(semester).remove(courseId);
				System.out.println("RmiInse.hashDataInse--"+ RmiInse.hashDataInse);
				removeFlag = true;
			}
		}
		if(removeFlag) {
			for ( String studId:enroll.keySet()){
				HashMap<String, HashSet<String>> studenthashinner1 = enroll.get(studId);
				HashSet<String> courseSet = studenthashinner1.get(semester);
				for(String coursestud:courseSet){
					if (coursestud.equals(courseId)){
						courseSet.remove(courseId);
						studenthashinner1.put(semester, courseSet);
						enroll.put(studId, studenthashinner1);
						System.out.println("in remove--"+enroll);
						break;
					}
				}
			}
			return true;
		}
		return false;
	}

	public String listCourseAvailability(String semester) {
		String term = semester.substring(0, semester.length()-1);
		System.out.println("term----"+term);
		String result="";
		if(semester.charAt(semester.length() - 1) == 'C') {
			result = RmiComp.listCourseAvailability(term);
		}
		else if(semester.charAt(semester.length() - 1) == 'S') {
			result = RmiSoen.listCourseAvailability(term);
		}
		else if(semester.charAt(semester.length() - 1) == 'I') {
			result = RmiInse.listCourseAvailability(term);
		}		
		return result;
	}

	public synchronized boolean enrolCourse(String studentId, String courseId, String semester) {
		check=0;
		System.out.println("recover--"+recover);
		if(recover>3) {
			HashMap<String,HashSet<String>> addCourse = new HashMap<String,HashSet<String>>();
			System.out.println("we are here 1"+semester);
			String checkdept = studentId.substring(0,4);
			String checkCourse = courseId.substring(0,4);
			if(!enroll.containsKey(studentId)) {
				System.out.println("we are here 6 new");
				if(checkdept.equals("COMP")) {
					System.out.println("we are here 2 new");
						enrolRes= RmiComp.getDetails(courseId,semester);
						System.out.println("enrolRes new imp ----" +enrolRes);
						checkEnroll = Boolean.parseBoolean(enrolRes.trim());
						System.out.println("checkEnroll imp----" +checkEnroll);
						if(checkEnroll) {
							hashset = new HashSet<String>();
							hashset.add(courseId);
							addCourse.put(semester,hashset);
							enroll.put(studentId, addCourse);
							System.out.println("enroll imp---1"+enroll);
							return true;
						}
				}
				else if(checkdept.equals("SOEN")) {
					System.out.println("we are here 2 new");
					enrolRes= RmiSoen.getDetails(courseId,semester);
					System.out.println("enrolRes new ----" +enrolRes);
					checkEnroll = Boolean.parseBoolean(enrolRes.trim());
					System.out.println("checkEnroll ----" +checkEnroll);
					if(checkEnroll) {
						hashset = new HashSet<String>();
						hashset.add(courseId);
						addCourse.put(semester,hashset);
						enroll.put(studentId, addCourse);
						System.out.println("enroll---1"+enroll);
						return true;
					}
				}
				else if(checkdept.equals("INSE")) {
					System.out.println("we are here 2 new");
					enrolRes= RmiInse.getDetails(courseId,semester);
					System.out.println("enrolRes new ----" +enrolRes);
					checkEnroll = Boolean.parseBoolean(enrolRes.trim());
					System.out.println("checkEnroll ----" +checkEnroll);
					if(checkEnroll) {
						hashset = new HashSet<String>();
						hashset.add(courseId);
						addCourse.put(semester,hashset);
						enroll.put(studentId, addCourse);
						System.out.println("enroll---1"+enroll);
						return true;
					}
				}
				
			}
			
			else {
				addCourse = enroll.get(studentId);
				if(!addCourse.containsKey(semester)) {
					fetchhashset = new HashSet<String>();
				}
				else{
					fetchhashset = addCourse.get(semester);
					System.out.println("fetchhashset.size() in else--"+fetchhashset.size());
				}
			if(fetchhashset.size()<3) {
				int checkDub = 0;
					System.out.println("fetchhashset.size()--"+fetchhashset.size());
					System.out.println("we are here 7");
					System.out.println("we are here 9");
					//System.out.println(addCourse.entrySet());
					
					getStudentId = enroll.get(studentId);
					System.out.println("getStudentId---"+getStudentId);	
					for(String sem :getStudentId.keySet()) {
						System.out.println("we are here 10"+sem);
						System.out.println("we are here 10");
						HashSet<String> s = getStudentId.get(sem);
						for(String course : s) {
							System.out.println("we are here 11"+course);
							if(course.equalsIgnoreCase(courseId)) {
								System.out.println("we are here 12");
								check = check+1;
								System.out.println("check"+check);
								break;
								
							}
								
							}
					}
					
					if(check==0) {
						//int checkDub = 0;
						Boolean checkEnrollElse=false;
						System.out.println("in check--");
						if(checkdept.equals("COMP")) {
							System.out.println("we are here 2");
							if(!checkCourse.equals("COMP")) {
							for(String sem :getStudentId.keySet()) {
								System.out.println("we are here 10"+sem);
								System.out.println("we are here 10");
								HashSet<String> s = getStudentId.get(sem);
								for(String course : s) {
									String checkDep = course.substring(0,4);
									System.out.println("we are here 11"+checkDep);
									if(checkDep.equals("SOEN")||checkDep.equals("INSE")) {
										System.out.println("we are here 12");
										checkDub = checkDub+1;
										System.out.println("checkDub--"+checkDub);
										
									}
										
									}
							}
						}
								if(checkDub<2) {	
									enrolRes= RmiComp.getDetails(courseId,semester);
									System.out.println("enrolRes ----" +enrolRes);
									checkEnrollElse = Boolean.parseBoolean(enrolRes.trim());
									System.out.println("checkEnrollElse ----" +checkEnrollElse);
									checkDub = 0;
								}
							//checkTask = studentTask(studentId,courseId,semester,hashData);
						}
						else if(checkdept.equals("SOEN")) {
							System.out.println("we are here 2");
							if(!checkCourse.equals("SOEN")) {
							for(String sem :getStudentId.keySet()) {
								System.out.println("we are here 10"+sem);
								System.out.println("we are here 10");
								HashSet<String> s = getStudentId.get(sem);
								for(String course : s) {
									String checkDep = course.substring(0,4);
									System.out.println("we are here 11"+checkDep);
									if(checkDep.equals("COMP")||checkDep.equals("INSE")) {
										System.out.println("we are here 12");
										checkDub = checkDub+1;
										System.out.println("checkDub--"+checkDub);
										
									}
										
									}
							}
						}
							if(checkDub<2) {
							enrolRes= RmiSoen.getDetails(courseId,semester);
							System.out.println("enrolRes ----" +enrolRes);
							checkEnrollElse = Boolean.parseBoolean(enrolRes.trim());
							System.out.println("checkEnroll ----" +checkEnroll);
							checkDub = 0;
							}
						}
						
						else if(checkdept.equals("INSE")) {
							System.out.println("we are here 2");
							if(!checkCourse.equals("INSE")) {
							for(String sem :getStudentId.keySet()) {
								System.out.println("we are here 10"+sem);
								System.out.println("we are here 10");
								HashSet<String> s = getStudentId.get(sem);
								for(String course : s) {
									String checkDep = course.substring(0,4);
									System.out.println("we are here 11"+checkDep);
									if(checkDep.equals("COMP")||checkDep.equals("SOEN")) {
										System.out.println("we are here 12");
										checkDub = checkDub+1;
										System.out.println("checkDub--"+checkDub);
										
									}
										
									}
							}
						}
							if(checkDub<2) {
							enrolRes= RmiInse.getDetails(courseId,semester);
							System.out.println("enrolRes ----" +enrolRes);
							checkEnrollElse = Boolean.parseBoolean(enrolRes.trim());
							System.out.println("checkEnroll ----" +checkEnroll);
							checkDub = 0;
						}
					}
						if(checkEnrollElse) {
							System.out.println("checkEnrollElse---"+checkEnrollElse);
							fetchhashset.add(courseId);
							addCourse.put(semester, fetchhashset);
							System.out.println("we are here 13 new");
							enroll.put(studentId, addCourse);
							//capacity--;
							System.out.println("enroll---"+enroll);
							//System.out.println("capacity---"+capacity);
							return true;
						}
					}
				
				}
			}
			
			return false;
		}
		else {
		HashMap<String,HashSet<String>> addCourse = new HashMap<String,HashSet<String>>();
		System.out.println("we are here 1"+semester);
		String checkdept = studentId.substring(0,4);
		String checkCourse = courseId.substring(0,4);
		if(!enroll.containsKey(studentId)) {
			System.out.println("we are here 6 new");
			if(checkdept.equals("COMP")) {
				System.out.println("we are here 2 new");
					enrolRes= RmiComp.getDetails(courseId,semester);
					System.out.println("enrolRes new imp ----" +enrolRes);
					checkEnroll = Boolean.parseBoolean(enrolRes.trim());
					System.out.println("checkEnroll imp----" +checkEnroll);
					if(checkEnroll) {
						hashset = new HashSet<String>();
						hashset.add(courseId);
						addCourse.put(semester,hashset);
						enroll.put(studentId, addCourse);
						System.out.println("enroll imp---1"+enroll);
						return false;
					}
			}
			else if(checkdept.equals("SOEN")) {
				System.out.println("we are here 2 new");
				enrolRes= RmiSoen.getDetails(courseId,semester);
				System.out.println("enrolRes new ----" +enrolRes);
				checkEnroll = Boolean.parseBoolean(enrolRes.trim());
				System.out.println("checkEnroll ----" +checkEnroll);
				if(checkEnroll) {
					hashset = new HashSet<String>();
					hashset.add(courseId);
					addCourse.put(semester,hashset);
					enroll.put(studentId, addCourse);
					System.out.println("enroll---1"+enroll);
					return false;
				}
			}
			else if(checkdept.equals("INSE")) {
				System.out.println("we are here 2 new");
				enrolRes= RmiInse.getDetails(courseId,semester);
				System.out.println("enrolRes new ----" +enrolRes);
				checkEnroll = Boolean.parseBoolean(enrolRes.trim());
				System.out.println("checkEnroll ----" +checkEnroll);
				if(checkEnroll) {
					hashset = new HashSet<String>();
					hashset.add(courseId);
					addCourse.put(semester,hashset);
					enroll.put(studentId, addCourse);
					System.out.println("enroll---1"+enroll);
					return false;
				}
			}
			
		}
		
		else {
			addCourse = enroll.get(studentId);
			if(!addCourse.containsKey(semester)) {
				fetchhashset = new HashSet<String>();
			}
			else{
				fetchhashset = addCourse.get(semester);
				System.out.println("fetchhashset.size() in else--"+fetchhashset.size());
			}
		if(fetchhashset.size()<3) {
			int checkDub = 0;
				System.out.println("fetchhashset.size()--"+fetchhashset.size());
				System.out.println("we are here 7");
				System.out.println("we are here 9");
				//System.out.println(addCourse.entrySet());
				
				getStudentId = enroll.get(studentId);
				System.out.println("getStudentId---"+getStudentId);	
				for(String sem :getStudentId.keySet()) {
					System.out.println("we are here 10"+sem);
					System.out.println("we are here 10");
					HashSet<String> s = getStudentId.get(sem);
					for(String course : s) {
						System.out.println("we are here 11"+course);
						if(course.equalsIgnoreCase(courseId)) {
							System.out.println("we are here 12");
							check = check+1;
							System.out.println("check"+check);
							break;
							
						}
							
						}
				}
				
				if(check==0) {
					//int checkDub = 0;
					Boolean checkEnrollElse=false;
					System.out.println("in check--");
					if(checkdept.equals("COMP")) {
						System.out.println("we are here 2");
						if(!checkCourse.equals("COMP")) {
						for(String sem :getStudentId.keySet()) {
							System.out.println("we are here 10"+sem);
							System.out.println("we are here 10");
							HashSet<String> s = getStudentId.get(sem);
							for(String course : s) {
								String checkDep = course.substring(0,4);
								System.out.println("we are here 11"+checkDep);
								if(checkDep.equals("SOEN")||checkDep.equals("INSE")) {
									System.out.println("we are here 12");
									checkDub = checkDub+1;
									System.out.println("checkDub--"+checkDub);
									
								}
									
								}
						}
					}
							if(checkDub<2) {	
								enrolRes= RmiComp.getDetails(courseId,semester);
								System.out.println("enrolRes ----" +enrolRes);
								checkEnrollElse = Boolean.parseBoolean(enrolRes.trim());
								System.out.println("checkEnrollElse ----" +checkEnrollElse);
								checkDub = 0;
							}
						//checkTask = studentTask(studentId,courseId,semester,hashData);
					}
					else if(checkdept.equals("SOEN")) {
						System.out.println("we are here 2");
						if(!checkCourse.equals("SOEN")) {
						for(String sem :getStudentId.keySet()) {
							System.out.println("we are here 10"+sem);
							System.out.println("we are here 10");
							HashSet<String> s = getStudentId.get(sem);
							for(String course : s) {
								String checkDep = course.substring(0,4);
								System.out.println("we are here 11"+checkDep);
								if(checkDep.equals("COMP")||checkDep.equals("INSE")) {
									System.out.println("we are here 12");
									checkDub = checkDub+1;
									System.out.println("checkDub--"+checkDub);
									
								}
									
								}
						}
					}
						if(checkDub<2) {
						enrolRes= RmiSoen.getDetails(courseId,semester);
						System.out.println("enrolRes ----" +enrolRes);
						checkEnrollElse = Boolean.parseBoolean(enrolRes.trim());
						System.out.println("checkEnroll ----" +checkEnroll);
						checkDub = 0;
						}
					}
					
					else if(checkdept.equals("INSE")) {
						System.out.println("we are here 2");
						if(!checkCourse.equals("INSE")) {
						for(String sem :getStudentId.keySet()) {
							System.out.println("we are here 10"+sem);
							System.out.println("we are here 10");
							HashSet<String> s = getStudentId.get(sem);
							for(String course : s) {
								String checkDep = course.substring(0,4);
								System.out.println("we are here 11"+checkDep);
								if(checkDep.equals("COMP")||checkDep.equals("SOEN")) {
									System.out.println("we are here 12");
									checkDub = checkDub+1;
									System.out.println("checkDub--"+checkDub);
									
								}
									
								}
						}
					}
						if(checkDub<2) {
						enrolRes= RmiInse.getDetails(courseId,semester);
						System.out.println("enrolRes ----" +enrolRes);
						checkEnrollElse = Boolean.parseBoolean(enrolRes.trim());
						System.out.println("checkEnroll ----" +checkEnroll);
						checkDub = 0;
					}
				}
					if(checkEnrollElse) {
						System.out.println("checkEnrollElse---"+checkEnrollElse);
						fetchhashset.add(courseId);
						addCourse.put(semester, fetchhashset);
						System.out.println("we are here 13 new");
						enroll.put(studentId, addCourse);
						//capacity--;
						System.out.println("enroll---"+enroll);
						//System.out.println("capacity---"+capacity);
						return false;
					}
				}
			
			}
		}
		
		return true;
		}
	}
	
	public String getClassSchedule(String studentID) {
		if(enroll.get(studentID)!=null) {
			classSchedule = enroll.get(studentID);
			String schedule = classSchedule.toString();
			return schedule;
		}
		else {
			String schedule=studentID + " " + "is not enrolled in any of the courses.";
			return schedule;
		}
	}
	
	public void Reset() throws RemoteException{
		if(enroll!=null) {
		enroll.clear();
		System.out.println(enroll);
		}
		if(classSchedule!=null) {
		classSchedule.clear();
		System.out.println(classSchedule);
		}
		if(getStudentId!=null) {
		getStudentId.clear();
		System.out.println(getStudentId);
		}
		RmiComp.hashDataComp.clear();
		RmiSoen.hashDataSoen.clear();
		RmiInse.hashDataInse.clear();
		RmiComp.inputValues("FALL");
		RmiComp.inputValues("WINTER");
		RmiComp.inputValues("SUMMER");
		System.out.println(RmiComp.hashDataComp);
		RmiSoen.inputValues("FALL");
		RmiSoen.inputValues("WINTER");
		RmiSoen.inputValues("SUMMER");
		System.out.println(RmiSoen.hashDataSoen);
		RmiInse.inputValues("FALL");
		RmiInse.inputValues("WINTER");
		RmiInse.inputValues("SUMMER");
		System.out.println(RmiInse.hashDataInse);
	}

	public synchronized boolean dropCourse(String studentID, String courseID) {
		System.out.println("courseID----------"+courseID);
		boolean dropFlag = false;
		String dropRes = "";
		String stud = studentID.substring(0,4).toUpperCase();
		if(enroll.get(studentID)!=null) {
			classSchedule = enroll.get(studentID);
			for(String sem :classSchedule.keySet()) {
				swapSem = sem;
				System.out.println("we are here 10"+sem);
				System.out.println("we are here 10");
				HashSet<String> s = classSchedule.get(sem);
				for(String course : s) {
					System.out.println("we are here 11"+course);
					if(course.equalsIgnoreCase(courseID)) {
						System.out.println("course12"+course);
						HashSet<String> hashsetDrop = classSchedule.get(sem);
						boolean b = hashsetDrop.remove(course);
						System.out.println(b);
						System.out.println("hashsetDrop-----"+hashsetDrop);
						classSchedule.put(sem, hashsetDrop);
						System.out.println("classSchedule-----"+classSchedule);
						enroll.put(studentID, classSchedule);
						System.out.println("enroll drop--"+enroll);
						dropFlag= true;
						break;
					}
						
					}
			}
			if(dropFlag) {
				System.out.println("dropFlag--");
				if(stud.equals("COMP")) {
					System.out.println("dropCOMP--");
					dropRes = RmiComp.getDropDetails(courseID);
					if(dropRes.trim().equals("true")) {
						return true;
					}
				}
				else if(stud.equals("SOEN")) {
					System.out.println("dropSOEN--");
					dropRes = RmiSoen.getDropDetails(courseID);
					if(dropRes.trim().equals("true")) {
						return true;
					}
				}
				else if(stud.equals("INSE")) {
					System.out.println("dropINSE--");
					dropRes = RmiInse.getDropDetails(courseID);
					if(dropRes.trim().equals("true")) {
						return true;
					}
				}
			}
			
		}
		return false;
	}
		
	public synchronized boolean swapCourse(String studentID, String oldCourseID, String newCourseID) {
		System.out.println("swap---");
		swapDFlag = dropCourse(studentID,oldCourseID.toUpperCase());
		System.out.println("swapFlag---"+ swapDFlag);
		if(swapDFlag) {
			System.out.println("swapSEM-------"+swapSem);
			swapEFlag = enrolCourse(studentID,newCourseID,swapSem);
			if((recover<3)&&swapEFlag) {
				swapEFlag=false;
				System.out.println("swapEFlag"+swapEFlag);
			}
			if((recover<3)&&(!swapEFlag)) {
				swapEFlag=true;
				System.out.println("swapEFlag"+swapEFlag);                                                                               
			}
			if(swapEFlag) {
				return true;
			}
			else {
				enrolCourse(studentID,oldCourseID,swapSem);
			}
		}
		return false;
	}
	
	/*@Override
	public void shutdown() {
		orb.shutdown(false);
	}*/
}
	
