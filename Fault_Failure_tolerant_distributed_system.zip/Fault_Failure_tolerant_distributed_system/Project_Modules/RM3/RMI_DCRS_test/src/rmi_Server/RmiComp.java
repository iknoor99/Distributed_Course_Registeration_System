package rmi_Server;

import java.rmi.*;

import java.rmi.server.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.net.*;
import java.io.*;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import DCRS.CORBA_InterfaceDCRS;
import DCRS.CORBA_InterfaceDCRSHelper;
import rmi_Client.RmiUser;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
public class RmiComp  {
	static  HashMap<String, Integer> hash;	
	static HashMap<String, Integer>hashDataseminner =new HashMap<String, Integer>();
	static HashMap<String, HashMap<String, Integer>> hashDataComp=new HashMap<String, HashMap<String, Integer>>();
	static HashMap<String, Integer> hashC = new  HashMap<String, Integer>();
	static String getData = "";
	static String liTerm = "";
	static String rep="";
	static String studId="";
	static String corId="";
	static String enrolRes="";
	static Logger logger = Logger.getLogger(RmiUser.class.getName());
	static private FileHandler fileTxt;
    static private SimpleFormatter formatterTxt;
	static HashMap<String, Integer> getValue;
	static HashMap<String, Integer> getValueDrop;

	
	public static void startRmiComp() throws RemoteException, MalformedURLException {
		//ORB orb = ORB.init(RMIPort,null);
		try {
			Runnable task = () -> {
				receive();
			};
			Thread thread = new Thread(task);
			thread.start();
			fileTxt = new FileHandler("G:\\workspace\\RMI_DCRS_test\\RmiComp.log");
		    formatterTxt = new SimpleFormatter();
	        fileTxt.setFormatter(formatterTxt);
	        logger.addHandler(fileTxt);
			
	        System.out.println("RmiComp Server ready and waiting ...");
	        logger.info("RmiComp Server registered");
	        System.out.println("RmiComp Server registered"); 
	        
	        inputValues("FALL");
	        inputValues("SUMMER");
	        inputValues("WINTER");
			}
		
		catch(Exception e) {
			System.out.println("Exception in RmiComp: " + e);
		}
	}
	
	public static void inputValues(String term) throws RemoteException {
		
		/*if(term == "fall") {
			hash = new HashMap<String, Integer>();
			hash.put("COMP6431", 10);
			hash.put("COMP6461", 10);
			hash.put("COMP6451", 10);
			hash.put("COMP6481", 10);
			hash.put("COMP6491", 10);
			hash.put("COMP6400", 10);
			
			if(!hashDataComp.containsKey(term)) {
				hashDataComp.put(term, hash);		
			}
		}
		
		if(term == "summer") {
			hash = new HashMap<String, Integer>();
			hash.put("COMP6431", 10);
			hash.put("COMP6461", 10);
			hash.put("COMP6594", 10);
			hash.put("COMP6595", 10);
			if(!hashDataComp.containsKey(term)) {
				hashDataComp.put(term, hash);
				
			}
		}
		
		if(term == "winter") {
			hash = new HashMap<String, Integer>();
			hash.put("COMP6641", 10);
			hash.put("COMP6594", 10);
			hash.put("COMP6681", 10);
			hash.put("COMP6621", 10);
			if(!hashDataComp.containsKey(term)) {
				hashDataComp.put(term, hash);
				
			}																																																																							
			
		}*/
		
		if(term == "FALL") {
			logger.info("***Adding Fall Courses in Comp Hashmap***");
			hash = new HashMap<String, Integer>();
			hash.put("COMP6431", 10);
			hash.put("COMP6461", 10);
			hash.put("COMP6451", 10);
			hash.put("COMP6481", 10);	
			if(!hashDataComp.containsKey(term)) {
				hashDataComp.put(term, hash);
			}
		}

		if(term == "SUMMER") {
			logger.info("***Adding Summer Courses in Comp Hashmap***");
			hash = new HashMap<String, Integer>();
			hash.put("COMP6592", 10);
			hash.put("COMP6593", 10);
			hash.put("COMP6481", 10);
			hash.put("COMP6595", 10);
			if(!hashDataComp.containsKey(term)) {
				hashDataComp.put(term, hash);
			}
		}
		if(term == "WINTER") {
			logger.info("***Adding Winter Courses in Comp Hashmap***");
			hash = new HashMap<String, Integer>();
			hash.put("COMP6641", 10);
			hash.put("COMP6651", 10);
			hash.put("COMP6481", 10);
			hash.put("COMP6621", 10);
			if(!hashDataComp.containsKey(term)) {
				hashDataComp.put(term, hash);
			}
	}
}
	
	public static String sendMessage(int serverPort,String common) {

		DatagramSocket aSocket = null;

		try {

			aSocket = new DatagramSocket();
          //  String text="Please send me the hash map for your server :" +common;
            String text = common;
			byte[] message = text.getBytes();

			InetAddress aHost = InetAddress.getByName("localhost");

			DatagramPacket request = new DatagramPacket(message, message.length, aHost, serverPort);

			aSocket.send(request);
			logger.info("Request message sent from the client to server with port number " + serverPort + " is: "

					+ new String(request.getData()));
			System.out.println("Request message sent from the client to server with port number " + serverPort + " is: "

					+ new String(request.getData()));

			byte[] buffer = new byte[1000];

			DatagramPacket reply = new DatagramPacket(buffer, buffer.length);

			aSocket.receive(reply);
			getData = new String(reply.getData());
			logger.info("Reply received from the server with port number " + serverPort + " is: "

					+ new String(reply.getData()));
			System.out.println("Reply received from the server with port number " + serverPort + " is: "

					+ new String(reply.getData()));
			

		} catch (SocketException e) {
			logger.info("Socket: " + e.getMessage());
			System.out.println("Socket: " + e.getMessage());

		} catch (IOException e) {

			e.printStackTrace();
			logger.info("IO: " + e.getMessage());
			System.out.println("IO: " + e.getMessage());

		} finally {

			if (aSocket != null)

				aSocket.close();

		}
		return getData;

	}

	private static void receive() {

		DatagramSocket aSocket = null;

		try {

			aSocket = new DatagramSocket(5555);
			logger.info("RmiComp server started............");
			System.out.println("RmiComp server started............");

			while (true) {
				byte[] buffer = new byte[1000];
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);

				aSocket.receive(request);
				
				String stringdata=new String (request.getData());
				//String stringdatasem = stringdata.split(":")[1].trim();
				String index[] = stringdata.split(",");
				System.out.println("index length--" + index.length);
				if(index.length<3) {
					liTerm = index[0];
					System.out.println("liTerm--" + liTerm);
				}
				else if(index.length<5) {
					//studId = index[0].trim();
					corId = index[0].trim();
					liTerm = index[1].trim();
					System.out.println("studId--" + studId);
					System.out.println("corId--" + corId);
					System.out.println("liTerm--" + liTerm);
				}
				String methodName = index[index.length - 1].trim();
				System.out.println("methodName--" + methodName);
				if(methodName.equals("LI")) {
					rep = getLi(liTerm);
				}
				else if(methodName.equals("enroll")) {
					rep = getEnrollDetails(corId,liTerm);
				}
				else if(methodName.equals("drop")) {
					rep = getDrop(liTerm);
				}
				buffer = rep.getBytes();

				DatagramPacket reply = new DatagramPacket(buffer, buffer.length, request.getAddress(),

						request.getPort());

				aSocket.send(reply);

			}

		} catch (SocketException e) {
			logger.info("Socket: " + e.getMessage());
			System.out.println("Socket: " + e.getMessage());

		} catch (IOException e) {
			logger.info("IO: " + e.getMessage());
			System.out.println("IO: " + e.getMessage());

		} finally {

			if (aSocket != null)

				aSocket.close();

	}

}
	
	private static String getDrop(String liTerm) {
		synchronized(hashDataComp) {
		for(String s:hashDataComp.keySet()) {
			System.out.println("soen---"+s);
			getValueDrop  =hashDataComp.get(s);
			for(String sa:getValueDrop.keySet()) {
				if(sa.equals(liTerm)) {
					int cap = getValueDrop.get(sa);
					cap++;
					getValueDrop.put(sa, cap);
					hashDataComp.put(s, getValueDrop);
					logger.info(liTerm+" Successfully dropped");
					return "true";
				}
			}
		}
		}
	return null;
	}

	public static String listCourseAvailability(String semester) {
			String result;
			hashC = hashDataComp.get(semester);
			List<HashMap<String, Integer>> d = Arrays.asList(hashDataComp.get(semester));
			result = "COMP" + hashC.toString();
			result= result + " "+"SOEN"+ sendMessage(7777,semester+","+"LI").trim() +" "+ "INSE"+ sendMessage(6666,semester+","+"LI").trim();
		    logger.info("list of available courses: "+ result);
			return result;
	}
	
	private static String getEnrollDetails(String corId, String liTerm) {
		synchronized(hashDataComp) {
		if(hashDataComp.containsKey(liTerm)) {
			//System.out.println("we are here 3");
			//System.out.println("hasmap data: "+hashDataComp.get(liTerm));
			getValue = hashDataComp.get(liTerm);
			if(getValue.containsKey(corId)) {
				//System.out.println("we are here 4");
				//System.out.println("capacity: "+getValue.get(corId));
				int capacity  = getValue.get(corId);
				if(capacity>0){
					//System.out.println("we are here 5");
					capacity--;
					getValue.put(corId, capacity);
					hashDataComp.put(liTerm, getValue);
					logger.info("Updated COMP hashmap: "+hashDataComp);
					//System.out.println("hashDataComp---"+hashDataComp);
					return "true";
				}
				else {
					logger.info("Course "+corId+ " is full for "+ liTerm );
				}
			}
		}
	}
	return "false";
}
	
	public static String getDetails(String courseId, String semester) {
		String checkCourse = courseId.substring(0,4).trim();
		System.out.println("checkCourse--"+checkCourse);
		String common = courseId+","+semester+","+"enroll";
		System.out.println("common---"+common);
		if(checkCourse.equals("COMP")) {
			System.out.println("in check course");
			synchronized(hashDataComp) {
			if(hashDataComp.containsKey(semester)) {
				System.out.println("1");
				System.out.println("we are here 3");
				System.out.println("hasmap data: "+hashDataComp.get(semester));
				getValue = hashDataComp.get(semester);
				if(getValue.containsKey(courseId)) {
					System.out.println("we are here 4");
					System.out.println("capacity: "+getValue.get(courseId));
					int capacity  = getValue.get(courseId);
					if(capacity>0){
						System.out.println("we are here 5");
						capacity--;
						getValue.put(courseId, capacity);
						hashDataComp.put(semester, getValue);
						System.out.println("hashDataComp---"+hashDataComp);
						return "true";
					}
				}
			}
		}
	}
		else if(checkCourse.equals("SOEN")) {
			enrolRes = sendMessage(7777,common);
			System.out.println("enrolRes ----" +enrolRes);
			return enrolRes.trim();
		}
		else if(checkCourse.equals("INSE")) {
			enrolRes = sendMessage(6666,common);
			System.out.println("enrolRes ----" +enrolRes);
			return enrolRes.trim();
		}
		return enrolRes;
	}
    
	private static String getLi(String liTerm) {
		HashMap<String, Integer> data = hashDataComp.get(liTerm);
		//List dataHash = (List) Arrays.asList(data);
		String  i = data.toString().trim();
		logger.info("List of courses available in "+liTerm + " are: "+ i);
	return i;
	}

	public static String getDropDetails(String courseId) {
		String dropC = "";
		String checkCourse = courseId.trim().substring(0,4).toUpperCase();
		String common = courseId.trim().toUpperCase()+","+"drop";
		System.out.println("common---"+common);
		
		if(checkCourse.equals("COMP")) {
			synchronized(hashDataComp) {
			for(String s:hashDataComp.keySet()) {
				System.out.println("s---"+s);
				getValueDrop  =hashDataComp.get(s);
				for(String sa:getValueDrop.keySet()) {
					if(sa.equals(courseId.toUpperCase())) {
						int cap = getValueDrop.get(sa);
						cap++;
						getValueDrop.put(sa, cap);
						hashDataComp.put(s, getValueDrop);
						logger.info("Course "+courseId+" is dropped");
						return "true";
					}
				}
			}
		}
	}
		else if(checkCourse.equals("SOEN")) {
			System.out.println("commonsoen---"+common);
			dropC = sendMessage(7777,common);
			System.out.println("dropC ----" +enrolRes);
			return dropC.trim();
		}
		else if(checkCourse.equals("INSE")) {
			dropC = sendMessage(6666,common);
			System.out.println("dropC ----" +enrolRes);
			return dropC.trim();
		}
		return "false";
	}
	
} // end class
