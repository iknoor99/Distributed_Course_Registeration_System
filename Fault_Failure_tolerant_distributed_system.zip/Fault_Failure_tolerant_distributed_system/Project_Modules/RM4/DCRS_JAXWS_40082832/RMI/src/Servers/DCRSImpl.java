package Servers;
import java.rmi.*;
import java.util.*;

import Servers.COMPServer;
import  Servers.INSEServer;
import Servers.SOENServer;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import Servers.DCRSInterface;



public class DCRSImpl implements DCRSInterface  {

	

	static HashMap<String, HashMap<String,HashSet<String>>> studentDetail = new HashMap<String, HashMap<String,HashSet<String>>>();
	HashMap<String, HashSet<String>> studinDetail= new HashMap<String, HashSet<String>>();
	HashMap<String, Integer> fetchedDetails;
	HashMap<String, Integer> fetchComp;
	HashMap<String, Integer> fetchSoen;
	HashMap<String, Integer> fetchInse;
	HashMap<String,HashSet<String>> fetchStudentId;
	HashMap<String,HashSet<String>> fetchedSchedule;

	HashSet<String> courseList;
	HashSet<String> getHash;
	HashSet<String> coursefetched;
	HashSet<String> fallData;
	HashSet<String> summerData;
	HashSet<String> winterData;

	HashMap<String, HashMap<String, Integer>> serverData;
	Boolean checkTask=false;
	Boolean flag=false;
	String responseString="";
	Boolean checkEnroll = false;
	boolean responseBool = false;
	String response = null;

	int count=0;
	
	
	public DCRSImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public boolean addCourse(String courseID, String semester,int capacity) {
		// TODO Auto-generated method stub
		String dept = courseID.substring(0, 4).toUpperCase();
		if(dept.equals("INSE")){
			if (INSEServer.inseData.get(semester).containsKey(courseID)) {
				return false;
			}
			else {	
			INSEServer.inseData.get(semester).put(courseID,capacity);
				return true;
		}
		}
		
		else if(dept.equals("COMP")){
			if(COMPServer.compData.get(semester).containsKey(courseID)) {
				return false;
			}
		else  {
				COMPServer.compData.get(semester).put(courseID,capacity);
				return true;
			}
			
		}
		else if(dept.equals("SOEN")){
			if(SOENServer.soenData.get(semester).containsKey(courseID)) {
				return false;
			}
			else  {
				SOENServer.soenData.get(semester).put(courseID,capacity);
				return true;
			}
			
		}
		
		return false;
	}

	
	public synchronized boolean removeCourse(String courseID, String semester) {
		
		// TODO Auto-generated method stub
		String dept = courseID.substring(0, 4).toUpperCase().trim();
		if(dept.equals("INSE")){
			if(!INSEServer.inseData.get(semester).containsKey(courseID)) {
//				INSEServer.inseData.get(semester).remove(courseID);
				checkTask=false;
				return false;

			}
		else {
			INSEServer.inseData.get(semester).remove(courseID);
			student(courseID,semester); 
			return true;
			}
		}  
		else if(dept.equals("COMP")){
		
			if(!COMPServer.compData.get(semester).containsKey(courseID)) {
				return false;

			}
			else  {
				COMPServer.compData.get(semester).remove(courseID);
				System.out.println("remove"+courseID);
				student(courseID,semester); 
				return true;
			}
			
		}
		else if(dept.equals("SOEN")){
			if(!SOENServer.soenData.get(semester).containsKey(courseID)) {
				return false;
			}
			else  {
				SOENServer.soenData.get(semester).remove(courseID);
				student(courseID,semester); 
				return true;
			}
			
		}
	
		return false;
	}

	
	public String listCourseAvailability(String semester) {
		String response=null;
		semester = semester.trim().toUpperCase();
		String term = semester.substring(0,semester.length()-1).toUpperCase().trim();
	//	String term=semester.substring(4, semester.length());
		char D = semester.charAt(semester.length() - 1);
		String Dept = Character.toString(D);
		if (Dept.equals("C")){
		response=COMPServer.listCourseAvailability(term);
	}
	else if (Dept.equals("S")){
		response=SOENServer.listCourseAvailability(term);			
	}
	else if (Dept.equals("I")){
		response=INSEServer.listCourseAvailability(term);			
	}
/*		if (semester.trim().startsWith("Comp")){
			response=COMPServer.listCourseAvailability(term);
		}
		else if(semester.trim().startsWith("Soen")) {
			response=SOENServer.listCourseAvailability(term);			
		}
		else if (semester.trim().startsWith("Inse")){
			response=INSEServer.listCourseAvailability(term);			
		}*/
		else{
			System.out.println("wrong semester entered ");
		}


		return response;
	}

		public synchronized boolean enrolCourse(String studentID, String courseID, String semester) {
		count=0;
		HashMap<String,HashSet<String>> addCourse = new HashMap<String,HashSet<String>>();
		String checkdept = studentID.substring(0,4).trim();
		String checkCourse = courseID.substring(0,4).trim();
		if(!studentDetail.containsKey(studentID)) {
			
			if(checkdept.equals("COMP")) {
				
				responseString= COMPServer.getDetails(courseID,semester);
					checkEnroll = Boolean.parseBoolean(responseString.trim());
					if(checkEnroll) {
						courseList = new HashSet<String>();
						courseList.add(courseID);
						addCourse.put(semester,courseList);
						studentDetail.put(studentID, addCourse);
						return true;
					}
			}
			else if(checkdept.equals("SOEN")) {
				
				responseString= SOENServer.getDetails(courseID,semester);
				checkEnroll = Boolean.parseBoolean(responseString.trim());
				if(checkEnroll) {
					courseList = new HashSet<String>();
					courseList.add(courseID);
					addCourse.put(semester,courseList);
					studentDetail.put(studentID, addCourse);
					return true;
				}
			}
			else if(checkdept.equals("INSE")) {
				
				responseString= INSEServer.getDetails(courseID,semester);
				checkEnroll = Boolean.parseBoolean(responseString.trim());
				if(checkEnroll) {
					courseList = new HashSet<String>();
					courseList.add(courseID);
					addCourse.put(semester,courseList);
					studentDetail.put(studentID, addCourse);
					return true;
				}
			}
			
		}
		
		else {
			addCourse = studentDetail.get(studentID);
			if(!addCourse.containsKey(semester)) {
				getHash = new HashSet<String>();
			}
			else{
				getHash = addCourse.get(semester);
			}
		if(getHash.size()<3) {
			int countCheck = 0;

				
				
				studinDetail = studentDetail.get(studentID);
				for(String sem :studinDetail.keySet()) {
					
					HashSet<String> subject = studinDetail.get(sem);
					for(String course : subject) {
						if(course.equalsIgnoreCase(courseID)) {
							count = count+1;
							System.out.println("count"+count);
							break;	
						}
							
						}
				}
				
				if(count==0) {
					System.out.println("hello");
					Boolean checkEnrollElse=false;	
					System.out.println("in check--");
					if(checkdept.equals("COMP")) {
						if(!checkCourse.equals("COMP")) {
							System.out.println("hello1");

						for(String sem :studinDetail.keySet()) {
							
							HashSet<String> subjectList = studinDetail.get(sem);
							for(String course : subjectList) {
								String checkDep = course.substring(0,4);
								
								if(checkDep.equals("SOEN")||checkDep.equals("INSE")) {
									
									countCheck = countCheck+1;
									System.out.println("countCheck--"+countCheck);
									
								}
									
								}
						}
						}
							if(countCheck<2) {	
								System.out.println("hello3");

								responseString= COMPServer.getDetails(courseID,semester);
								System.out.println("responseString " +responseString);
								checkEnrollElse = Boolean.parseBoolean(responseString.trim());
								System.out.println("checkEnrollElse " +checkEnrollElse);
								countCheck=0;
							}
						//checkTask = studentTask(studentId,courseId,semester,hashData);
					}
					else if(checkdept.equals("SOEN")) {
						if(!checkCourse.equals("SOEN")) {
							System.out.println("hello4");

						for(String sem :studinDetail.keySet()) {
							
							HashSet<String> subjectList = studinDetail.get(sem);
							for(String course : subjectList) {
								String checkDep = course.substring(0,4);
								
								if(checkDep.equals("COMP")||checkDep.equals("INSE")) {
									
									countCheck = countCheck+1;
									
									
								}
									
								}
						}
						}
						
						if(countCheck<2) {
							System.out.println("hello5");

							responseString= SOENServer.getDetails(courseID,semester);
//						System.out.println("responseString " +responseString);
						checkEnrollElse = Boolean.parseBoolean(responseString.trim());
//						System.out.println("checkEnroll " +checkEnroll);
						countCheck=0;
						}
					}
					
					else if(checkdept.equals("INSE")) {
						if(!checkCourse.equals("INSE")) {

						for(String sem :studinDetail.keySet()) {
							
							HashSet<String> subjectList = studinDetail.get(sem);
							for(String course : subjectList) {
								String checkDep = course.substring(0,4);
								
								if(checkDep.equals("COMP")||checkDep.equals("SOEN")) {
									
									countCheck = countCheck+1;
//									System.out.println("countCheck"+countCheck);	
								}
									
								}
						}
						}
						
						if(countCheck<2) {
							responseString= INSEServer.getDetails(courseID,semester);
//						System.out.println("responseString " +responseString);
						checkEnrollElse = Boolean.parseBoolean(responseString.trim());
//						System.out.println("checkEnroll " +checkEnroll);
						countCheck=0;
					}
				}
					if(checkEnrollElse) {
						getHash.add(courseID);
						addCourse.put(semester, getHash);
						
						studentDetail.put(studentID, addCourse);
					
						return true;
					}
				}
			
			}
		}
		
		return false;
	}
	
	

	
	@Override
	public String getClassSchedule(String studentID) {

		// TODO Auto-generated method stub
		
		System.out.println(studentDetail);
		if(studentDetail.get(studentID)!=null) {
			
			studinDetail = studentDetail.get(studentID);
			fallData = studinDetail.get("fall");
			winterData = studinDetail.get("winter");
			summerData = studinDetail.get("summer");
			System.out.println(studentID + " " + "is enrolled in below courses:");
			System.out.println("Fall:" + " " + fallData);
			System.out.println("Winter:" + " " + winterData);
			System.out.println("Summer:" + " " + summerData);
			fetchedSchedule = studentDetail.get(studentID);
			List<HashMap<String, HashSet<String>>> fetchedList = Arrays.asList(fetchedSchedule);

			return fetchedSchedule.toString();
		}
		else {
			String Res=studentID + " " + "is not enrolled in any of the courses.";
			return Res;
		//	return " ";
		}
		
	}
		
		
		
	

	@Override
	public synchronized boolean dropCourse(String studentID, String courseID) {
		
		String student = studentID.substring(0,4).toUpperCase();
		if(studentDetail.get(studentID)==null){
			return false;

		}
		else  {
			fetchedSchedule = studentDetail.get(studentID);
			Set<String> keySet = fetchedSchedule.keySet();
			Iterator<String> keySetIterator = keySet.iterator();
			while (keySetIterator.hasNext()) {
			 String term = keySetIterator.next();

				HashSet<String> subject = fetchedSchedule.get(term);
				Iterator<String> itr = subject.iterator();
		        while(itr.hasNext()){
//				for(String course : subject) {
		        	String course = itr.next();
					if(course.equalsIgnoreCase(courseID)) {
						
						HashSet<String> hashsetDrop = fetchedSchedule.get(term);
						boolean flag = hashsetDrop.remove(course);
						
						System.out.println("courses left"+hashsetDrop);
						fetchedSchedule.put(term, hashsetDrop);
						studentDetail.put(studentID, fetchedSchedule);
						responseBool= true;
						break;
					}
						
					}
			}
			if(!responseBool){
				return false;
			}
			else  {	
				boolean operation=dropOperation(courseID,student);
				if(operation) {
					return true;
				}
				
			}
			
		}
		return false;
	}

	@Override
	public synchronized boolean swapCourse(String StudentID, String oldCourseID, String newCourseID) {
		boolean checkCourse=false;
		boolean enrollOperation=false;
		boolean dropOperation=false;
		String Semester="";
		if (studentDetail.containsKey(StudentID)) {
		studinDetail=studentDetail.get(StudentID);
		for(String sem :studinDetail.keySet()){
			HashSet<String> s=studinDetail.get(sem);
			for(String course:s){
				if(course.equals(oldCourseID)){
					Semester=sem;
					break;
				}
			}
		}
//		System.out.println(studentDetail);
		
//			studinDetail=studentDetail.get(StudentID);
//			System.out.println(studentDetail);
//
//			if (studinDetail.containsKey("fall")) {
//			fallData = studinDetail.get("fall");
//			}
//			if (studinDetail.containsKey("winter")) {
//			winterData = studinDetail.get("winter");
//			}
//			if (studinDetail.containsKey("summer")) {
//			summerData = studinDetail.get("summer");
//			}
//			System.out.println(fallData);
//			if(summerData.contains(oldCourseID)) {
//				Semester = "summer";
//				checkCourse =true; 
//				}
//			else if(winterData.contains(oldCourseID)) {
//				Semester = "winter";
//				checkCourse =true;}
//			 
//			else  if(fallData.contains(oldCourseID)) {
//					Semester = "fall";
//					checkCourse =true;}
			if(Semester!=null) {
				dropOperation=dropCourse(StudentID,oldCourseID);
				if(dropOperation) {
					enrollOperation=enrolCourse(StudentID,newCourseID,Semester);
					
				    if(enrollOperation) {
				    	System.out.println("Swap done after drop and enroll");
				    	return true;
				    }	
				    else {
				    	System.out.println(" drop success and enroll unsuccesful");
				    	enrolCourse(StudentID,oldCourseID,Semester);
				    }
				}
				else {
					System.out.println("unable to enroll");	
				}
			}
			else {
				System.out.println("Student not enrolled in-"+oldCourseID);
			}
			
			
		}
		else {
			System.out.println(StudentID + " " + "is not enrolled in any course.");
			
		}
		
		
		return false;
	}
	
		public void student(String courseID, String semester) {
			for ( String studentId:studentDetail.keySet()){
//				HashMap<String, HashSet<String>> studinDetail1= new HashMap<String, HashSet<String>>();

				studinDetail = studentDetail.get(studentId);
				HashSet<String> courseListing = studinDetail.get(semester);
				Iterator<String> itr = courseListing.iterator();
		        while(itr.hasNext()){
		        	String fetchedCourse = itr.next();
				
					if (fetchedCourse.equals(courseID)){

						courseListing.remove(fetchedCourse);

						studinDetail.put(semester, courseListing);
						studentDetail.put(studentId, studinDetail);
						System.out.println(studentDetail);
						
					}
				}
			}
		
			
		}
	
		public boolean dropOperation(String courseID,String student) {
//			String student = studentID.substring(0,4).toUpperCase();
			if(student.equals("INSE")) {
				response = INSEServer.getDropDetails(courseID);
				if(response.trim().equals("true")) {
					return true;
				}
			}
			else if(student.equals("COMP")) {
				response = COMPServer.getDropDetails(courseID);
				if(response.trim().equals("true")) {
					return true;
				}
			}
			else if(student.equals("SOEN")) {
				response = SOENServer.getDropDetails(courseID);
				if(response.trim().equals("true")) {
					return true;
				}
			}
			return false;
		}
}
