package service;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.net.URL;
import java.net.MalformedURLException;


import Servers.DCRSInterface;


public class testClient extends Thread {
	String serverName;
	String studentID="";
	String courseID=null;
	String oldcourseID=null;
	String newcourseID=null;
	static Servers.DCRSInterface server;
	static String[] ref=null;
	String getSchedule;


	String semester=null;
	
	public testClient(String server,String studentId,String term,String oldCourseId,String newCourseId) {
		// TODO Auto-generated constructor stub
		serverName=server;
		studentID=studentId.toUpperCase();
		oldcourseID=oldCourseId.toUpperCase();
		newcourseID=newCourseId.toUpperCase();
		semester=term;
		
	}

	public static void main(String[] args) throws MalformedURLException {
		
		// TODO Auto-generated method stub
		ref=args;
		testClient d1 = new testClient("COMPServer", "COMPS1001","summer","comp6592","comp6593");
		Thread td1 = new Thread (d1);
		testClient d2 = new testClient("COMPServer", "COMPS1002","summer","comp6592","comp6593");
		Thread td2 = new Thread (d2);
		testClient d3 = new testClient("COMPServer", "COMPS1003","summer","comp6592","comp6593");
		Thread td3 = new Thread (d3);
		testClient d4 = new testClient("COMPServer", "COMPS1001","fall","comp6431","comp6451");
		Thread td4 = new Thread (d4);
		testClient d5 = new testClient("COMPServer", "COMPS1005","fall","comp6461","comp6451");
		Thread td5 = new Thread (d5);
		
		
		testClient m1 = new testClient("SOENServer", "SOENS1001","fall","soen6461","soen6451");
		Thread tm1 = new Thread (m1);
		testClient m2 = new testClient("SOENServer", "SOENS1002","fall","soen6461","soen6451");
		Thread tm2 = new Thread (m2);
		testClient m3 = new testClient("SOENServer", "SOENS1003","fall","soen6461","soen6451");
		Thread tm3 = new Thread (m3);
		testClient m4 = new testClient("SOENServer", "SOENS1004","fall","soen6461","soen6451");
		Thread tm4 = new Thread (m4);
		testClient m5 = new testClient("SOENServer", "SOENS1005","fall","soen6461","soen6451");
		Thread tm5 = new Thread (m5);
//		
		
		testClient l1 = new testClient("INSEServer", "INSES1001","fall","inse6461","inse6451");
		Thread tl1 = new Thread (l1);		
		testClient l2 = new testClient("INSEServer", "INSES1002","fall","inse6461","inse6451");
		Thread tl2 = new Thread (l2);
		testClient l3 = new testClient("INSEServer", "INSES1003","fall","inse6461","inse6451");
		Thread tl3 = new Thread (l3);
		testClient l4 = new testClient("INSEServer", "INSES1004","fall","inse6461","inse6451");
		Thread tl4 = new Thread (l4);
		testClient l5 = new testClient("INSEServer", "INSES1005","fall","inse6461","inse6451");
		Thread tl5 = new Thread (l5);
//		
		
		
		
		
		
		td1.start();
		td2.start();
		td3.start();
		td4.start();
		td5.start();
//		
		
//		
		tm1.start();
		tm2.start();
		tm3.start();
		tm4.start();
		tm5.start();
//		
		
		
		
		tl1.start();
		tl2.start();
		tl3.start();
		tl4.start();
		tl5.start();
//		
	}

	public void run() {
		
		try {
			if (serverName.equalsIgnoreCase("COMPServer")) {
				URL compURL = new URL("http://localhost:8080/comp?wsdl");
				QName compQName = new QName("http://Servers/", "DCRSImplService");
				Service compService = Service.create(compURL, compQName);
				

			 server = compService.getPort(DCRSInterface.class);
		 }
			else if (serverName.equalsIgnoreCase("SOENServer")) {

				URL soenURL = new URL("http://localhost:8080/soen?wsdl");
				QName soenQName = new QName("http://Servers/", "DCRSImplService");
				Service soenService = Service.create(soenURL, soenQName);
				

			 server = soenService.getPort(DCRSInterface.class);
			}
			else if (serverName.equalsIgnoreCase("INSEServer")) {
				URL inseURL = new URL("http://localhost:8080/inse?wsdl");
				QName inseQName = new QName("http://Servers/", "DCRSImplService");
				Service inseService = Service.create(inseURL, inseQName);
				

			   server = inseService.getPort(DCRSInterface.class);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		

		boolean enrollSuccess=server.enrolCourse(studentID, oldcourseID, semester);
		if(enrollSuccess) {
//			logger.info("Enrollment Successful for"+inputID+"for course " +courseId);
			System.out.println("Enrollment Successful for"+studentID+"for course " +oldcourseID+"\n");
			
		}
		else {
//			logger.info("Enrollment unSuccessful for"+inputID+"for course " +courseId);
			System.out.println("Enrollment unSuccessful for"+studentID+"for course " +oldcourseID+"\n");	
		}
		getSchedule=server.getClassSchedule(studentID);
		if(getSchedule!=null) {
//			logger.info("fetched schedule  "+getSchedule);
			
			System.out.printf("fetched schedule %s for student id %s \n",getSchedule,studentID);
			
		}
		else {
//			logger.info("No schedule found for this Id");
			System.out.println("No schedule found for this Id "+studentID+" \n");	
		}
		boolean swapSuccess=server.swapCourse(studentID, oldcourseID, newcourseID);
		if(swapSuccess) {
//			logger.info("Swapped Successfully"+courseId);
			System.out.printf("%s Swapped Successfully \n",oldcourseID);
			
		}
		

		else {
//			logger.info("Unable to swap"+oldcourseID);
			System.out.println("Unable to swap"+oldcourseID+"\n");	
		}

		boolean dropSuccess=server.dropCourse(studentID, newcourseID);
		if(dropSuccess) {
//			logger.info("Dropped Successfully"+courseId);
			System.out.printf("%s Dropped Successfully for student id %s \n",newcourseID,studentID);
			
		}
		

		else {
//			logger.info("Unable to Drop"+courseId);
			System.out.println("Unable to Drop"+oldcourseID+"for student id"+studentID+"\n");	
		}

	}
}
