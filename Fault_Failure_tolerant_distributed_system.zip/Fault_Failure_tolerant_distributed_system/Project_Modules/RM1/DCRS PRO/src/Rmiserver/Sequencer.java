package Rmiserver;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Sequencer {

		public static String reqReceived;
		public static int number = -1;
		public static String repManagerAddress;
		public static String repManagerPort;
		public static String finalRequest;
		
		private static void receive() {
			DatagramSocket aSocket = null;
			try {
				SendRequest(finalRequest);
				aSocket = new DatagramSocket(6666);
				byte[] buffer = new byte[1000];
				System.out.println("Sequencer started at port no 6666");
				while (true) {
					DatagramPacket request = new DatagramPacket(buffer, buffer.length);
					aSocket.receive(request);
					reqReceived = new String(request.getData());
					System.out.println("Request received is :" + " " + reqReceived);	
					finalRequest = addSeqNumber(reqReceived.trim());
					System.out.println(finalRequest);
					SendRequest(finalRequest);
				}
			} catch (SocketException e) {
				System.out.println("Socket: " + e.getMessage());
			} catch (IOException e) {
				System.out.println("IO: " + e.getMessage());
			} finally {
				if (aSocket != null)
					aSocket.close();
			}
			
			
		}

		 private static void SendRequest(String finalRequest) {
			 System.out.println("sending replica");
			 sendToReplica("230.1.1.5", 1313);
			 
		}
		 
		private static void sendToReplica(String repManagerAddress, int repManagerPort) {
			DatagramSocket aSocket = null;
			try {
				aSocket = new DatagramSocket();
				finalRequest = "enrolCourse,COMPS1111,COMP6231,FALL,0";
				System.out.println("finalRequest"+finalRequest);
				byte[] message = finalRequest.getBytes();
				InetAddress aHost = InetAddress.getByName(repManagerAddress);
				DatagramPacket request = new DatagramPacket(message, finalRequest.length(), aHost, repManagerPort);
				aSocket.send(request);
				System.out.println("Request message sent from the Sequencer to replica at port number "+ repManagerPort + " is: "
						+ new String(request.getData()));
			} catch (SocketException e) {
				System.out.println("Socket: " + e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("IO: " + e.getMessage());
			} finally {
				if (aSocket != null)
					aSocket.close();
			}
			
		}

		public static String addSeqNumber(String request){
			 	String uniqueRequest= null;   
			 	number+=1; 
			 	uniqueRequest = request+","+number;
				return uniqueRequest;
		    }
		
		public static void main(String args[]) {
		    
			try{			
				Runnable task = () -> {
					receive();
				};		
				Thread thread = new Thread(task);			
				thread.start();
			}		
		     catch (Exception re) {
		         System.out.println("Exception : " + re);	         
		      }			
		}	
	}