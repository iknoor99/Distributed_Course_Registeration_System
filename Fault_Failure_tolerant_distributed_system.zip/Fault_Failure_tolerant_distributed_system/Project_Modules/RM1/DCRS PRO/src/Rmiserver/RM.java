package Rmiserver;
	
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

public class RM {
	
	static String studentId="";
	static String advisorId="";
	static String courseId="";
	static String semester="";
	static String sequence="";
	static String capacity="";
	static String newCourseID = "";
	static String array[]=new String[70];
	static int lseq =0;
	static boolean flag1 = false;
	static String replicaId = "";
	static int rm3Count = 0;
	static int[] vector = {0,0,0,0};
	static int index11=0;
	
	public RM () {
		
	}

	public static void udp(String message) {
		DatagramSocket aSocket = null;
		System.out.println("message--"+message);
		try {
			aSocket = new DatagramSocket();
			byte[] m = message.getBytes();
			InetAddress aHost = InetAddress.getByName("230.1.1.5");
			DatagramPacket request = new DatagramPacket(m, m.length, aHost, 1314);
			aSocket.send(request);
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	public static void main(String args[]) throws InvalidName, AdapterInactive, ServantNotActive, WrongPolicy, org.omg.CosNaming.NamingContextPackage.InvalidName, NotFound, CannotProceed, SecurityException, IOException {
		CompServer.startCompServer();				    
		InseServer.startInseServer();		    
		SoenServer.startSoenServer();
		Functions imp = new Functions();
		
		MulticastSocket aSocket = null;
		try {

			aSocket = new MulticastSocket(1313);

			aSocket.joinGroup(InetAddress.getByName("230.1.1.5"));

			
			System.out.println("Server Started............");

			while (true) {
				byte[] buffer = new byte[1000];
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
				aSocket.receive(request);
				System.out.println("abcd---"+request.getData().toString());
				String inputreq=new String (request.getData());
				String index[] = inputreq.split(",");
				System.out.println("index length--" + index.length);
				// Handling array		
				/*int cseq = Integer.parseInt(index1[4].trim());
				System.out.println("Current sequence is:"+cseq);
				array[cseq] = inputreq; */
				
			/*	for(int i=lseq+1;i<=cseq;i++) {
					if(array[i].equals("")) {
						flag1=false;
						break;
					}else {
						flag1=true;
						break;
					}
				}
				if(flag1) {*/
					/*String stringdata=new String (request.getData());
					String index[] = stringdata.split(",");*/
					System.out.println("index length--" + index.length);
				if(index[0].trim().equals("addCourse")) {
					courseId = index[1].trim();
					semester = index[2].trim();
					capacity = index[3].trim();
					sequence = index[4].trim();
					int cap = Integer.parseInt(capacity.trim());
					boolean add = imp.addCourse(courseId, semester, cap);
					String str = String.valueOf(add);
					udp(str+",RM1");
				}
				else if(index[0].trim().equals("removeCourse")) {
					courseId = index[1].trim();
					semester = index[2].trim();
					sequence = index[3].trim();
					boolean rem = imp.removeCourse(courseId, semester);
					String str = String.valueOf(rem);
					udp(str+",RM1");
				}
				else if(index[0].trim().equals("listCourseAvailability")) {
					semester = index[1].trim();
					sequence = index[2].trim();
					String str = imp.listCourseAvailability(semester);
					udp(str+",RM1");
				}
				else if(index[0].trim().equals("enrolCourse")) {
					studentId = index[1].trim();
					courseId = index[2].trim();
					semester = index[3].trim();
					sequence = index[4].trim();
					boolean enrol = imp.enrolCourse(studentId, courseId, semester);
					String str = String.valueOf(enrol);
					udp(str+",RM1");
				}
				else if(index[0].trim().equals("dropCourse")) {
					studentId = index[1].trim();
					courseId = index[2].trim();
					sequence = index[3].trim();
					boolean drop = imp.dropCourse(studentId, courseId);
					String str = String.valueOf(drop);
					udp(str+",RM1");
				}
				else if(index[0].trim().equals("getClassSchedule")) {
					studentId = index[1].trim();
					sequence = index[2].trim();
					String str = imp.getClassSchedule(studentId);
					udp(str+",RM1");
				}
				else if(index[0].trim().equals("swapCourse")) {
					studentId = index[1].trim();
					courseId = index[3].trim();
					newCourseID = index[2].trim();
					sequence = index[4].trim();
					boolean swap = imp.swapCourse(studentId, newCourseID, courseId);
					String str = String.valueOf(swap);
					udp(str+",RM1");
				}
			/*	DatagramPacket reply = new DatagramPacket(request.getData(), request.getLength(), request.getAddress(),
						request.getPort());
				aSocket.send(reply);
				lseq = cseq;
				}else {
					// do nothing
				}*/
				else if(index[0].trim().equals("faulty")) {
					replicaId =index[1].trim();
					
					System.out.println(replicaId);
					if(replicaId.equals("RM1")) {
						vector[0]=vector[0]+1;
					}
					
					else if(replicaId.equals("RM2")) {
						vector[1]=vector[1]+1;
					}
					else if(replicaId.equals("RM3")) {
						vector[2]=vector[2]+1;
					}
					
					else if(replicaId.equals("RM4")) {
						vector[3]=vector[3]+1;
					}
					
//					if(vector[2]>3) {
//						imp.recover = vector[2];
//					}
					
				}}

		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
		
	
	}
}