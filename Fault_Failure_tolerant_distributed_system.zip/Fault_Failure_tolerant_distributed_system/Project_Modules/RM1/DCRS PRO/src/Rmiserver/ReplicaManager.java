package Rmiserver;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.rmi.RemoteException;

public class ReplicaManager {

	public static String reqReceived;
	public static String result = "";
	
	private static void receive() {
		DatagramSocket aSocket = null;
		try {
			aSocket = new DatagramSocket(7777);
			byte[] buffer = new byte[1000];
			System.out.println("Sequencer started at port no 7777");
			while (true) {
				DatagramPacket request = new DatagramPacket(buffer, buffer.length);
				aSocket.receive(request);
				reqReceived = new String(request.getData());
				System.out.println("Request received is :" + " " + reqReceived);	
				DecodeRequest(reqReceived.trim());
			}
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}

	}

	private static void DecodeRequest(String request) throws RemoteException {
		Functions fun = new Functions();
		boolean flag=false;
		String func=request.split(",")[0];
		func=func.trim();
		if(func.equals("enrolCourse")) {
			String []parm=request.split(",",5);
			String studentid=parm[1];
			studentid=studentid.trim();
			String courseID =parm[2];
			courseID=courseID.trim();
		    String semester =parm[3];
			semester=semester.trim();
			String sequence =parm[4];
			sequence=sequence.trim();
			flag = fun.enrolCourse(studentid,courseID,semester);
			if(flag) {
				result = "true";
			}else {
				result = "false";
			}
		}else if(func.equals("dropCourse")) {
			String []parm=request.split(",",4);
			String studentid=parm[1];
			studentid=studentid.trim();
			String courseID =parm[2];
			courseID=courseID.trim();
			String sequence =parm[3];
			sequence=sequence.trim();
			flag = fun.dropCourse(studentid, courseID);
			if(flag) {
				result = "true";
			}else {
				result = "false";
			}
		}else if(func.equals("getClassSchedule")) {
			String []parm=request.split(",",3);
			String studentid=parm[1];
			studentid=studentid.trim();
			String sequence =parm[2];
			sequence=sequence.trim();
			result = fun.getClassSchedule(studentid);
		}else if(func.equals("swapCourse")) {
			String []parm=request.split(",",5);
			String studentid=parm[1];
			studentid=studentid.trim();
			String oldcourseID =parm[2];
			oldcourseID=oldcourseID.trim();
		    String newcourseID =parm[3];
		    newcourseID=newcourseID.trim();
		    String sequence =parm[4];
			sequence=sequence.trim();
			flag = fun.swapCourse(studentid, oldcourseID, newcourseID);
			if(flag) {
				result = "true";
			}else {
				result = "false";
			}
		}else if(func.equals("addCourse")) {
			String []parm=request.split(",",5);
			String courseid=parm[1];
			courseid=courseid.trim();
			String semester =parm[2];
			semester=semester.trim();
		    String capacity =parm[3];
		    capacity=capacity.trim();
		    int cap =Integer.parseInt(capacity);
		    String sequence =parm[4];
			sequence=sequence.trim();
			flag = fun.addCourse(courseid, semester, cap);
			if(flag) {
				result = "true";
			}else {
				result = "false";
			}
		}else if(func.equals("removeCourse")) {
			String []parm=request.split(",",4);
			String courseid=parm[1];
			courseid=courseid.trim();
			String semester =parm[2];
			semester=semester.trim();
			String sequence =parm[3];
			sequence=sequence.trim();
			flag = fun.removeCourse(courseid, semester);
			if(flag) {
				result = "true";
			}else {
				result = "false";
			}
		}else if(func.equals("listCourseAvailability")){
			String []parm=request.split(",",3);
			String semester=parm[1];
			semester=semester.trim();
			String sequence =parm[2];
			sequence=sequence.trim();
			result = fun.listCourseAvailability(semester);
		}
		sendToFE();
	}
	
	private static void sendToFE() {
		DatagramSocket aSocket = null;
		try {
			int repManagerPort = 1315;
			aSocket = new DatagramSocket();
			byte[] message = result.getBytes();
			InetAddress aHost = InetAddress.getByName("230.1.1.6");
			DatagramPacket request = new DatagramPacket(message, result.length(), aHost, repManagerPort);
			aSocket.send(request);
			System.out.println("Request message sent from the replica to Front end at port number "+ repManagerPort + " is: "
					+ new String(request.getData()));
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("IO: " + e.getMessage());
		} finally {
			if (aSocket != null)
				aSocket.close();
		}
		
	}
	
}
